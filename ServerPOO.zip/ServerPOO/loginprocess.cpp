
#include "loginprocess.h"
#include "server.h"
#include "QDataStream"
#include "cprotocol.h"
#include <QSqlQuery>

void loginProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    this->username=this->tokens[0];
    this->tokens.removeAt(0);
    this->password=this->tokens[0];
    this->tokens.removeFirst();
    //this->clientID=Server::getInstance()->giveID(this->username);
}

loginProcess::loginProcess(QList<QByteArray> tokens):CProcess(tokens)
{
}

void loginProcess::run()
{
    read_from_socket();
    if(checkforCredentials()){
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::ValidCredentials).toUtf8();
        block_to_send=block_to_send+protocol+" "+this->clinetId.toUtf8()+" "+this->type.toUtf8();
    }else{
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::InvalidCredentials).toUtf8();
        block_to_send=block_to_send+protocol;

    }


}

bool loginProcess::checkforCredentials()
{
    //return true;
    QSqlQuery query;
    query.prepare("SELECT * FROM Conturi WHERE utilizator = :utilizator and parola = :parola");
    query.bindValue(":utilizator",this->username);
    query.bindValue(":parola",this->password);

    query.exec();
    if(query.next()){
        this->clinetId=query.value(0).toString();
        this->type=query.value(3).toString();
        return true;
    }
    else return false;
}




