
#ifndef MERGEPROCESS_H
#define MERGEPROCESS_H

#include "cprocess.h"

#include <QString>
#include <QDateTime>

class MergeProcess : public CProcess
{
    QString repositoryName;
    QString branch1;
    QString file1;
    QString branch2;
    QString file2;
    QString getOriginal(QString filename);
public:
    MergeProcess(QList<QByteArray> tokens);
    void read_from_socket();
    void run()override;
    void merge();
    bool check_with_original();
    QDateTime get_date_from_string(QString line);
    int check_most_recent(QDateTime date1, QDateTime date2);
};

#endif // MERGEPROCESS_H
