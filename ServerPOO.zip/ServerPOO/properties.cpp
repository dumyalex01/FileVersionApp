#include "properties.h"
#include "textfile.h"
#include "cprotocol.h"
#include "server.h"

#include <qDebug>
#include <fstream>
using namespace std;
QString Properties::transformToName(QString id)
{
    for(int i=0;i<this->NumeID.size();i++)
        if(this->NumeID[i].first==id)
            return this->NumeID[i].second;
}

Properties::Properties(QByteArrayList tokens):CProcess(tokens)
{
}

void Properties::read_from_socket()
{
    this->tokens.removeFirst();
    this->id=this->tokens[0];
    this->NumeID=Server::getInstance()->getNameID();
}


void Properties::run()
{
    read_from_socket();

    char path[250];
    strcpy(path,"C:/Users/Alex/Desktop/test/repository_list.txt");
    fstream file(path);
    char buffer[250];
    QString message;
    while(file.getline(buffer,250))
    {
        TextFile A(buffer,"turnck");
        if(A.check_access(this->id.toInt()))
        {   QString accessPath;
            accessPath.append("C:/Users/Alex/Desktop/test/");
            accessPath.append(buffer);
            accessPath.append("/");
            accessPath.append(buffer);
            accessPath.append("_access.txt");
            message.append(buffer);
            message.append(":");
            QFile f(accessPath);
            if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
                qDebug()<<"eroare";
                QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::PropertiesFailed).toUtf8();
                block_to_send=block_to_send+protocol+" ";
            }
            while (!f.atEnd()) {
                QByteArray line = f.readLine();
                QString idd=QString::fromUtf8(line);
                QStringList listaAux=idd.split('\n');
                message.append(this->transformToName(listaAux.at(0)));
                // qDebug()<<message;
                message.append(" ");

            }
        }



        message.append("\n");
    }

    QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::PropertiesExecuted).toUtf8();
    block_to_send=block_to_send+protocol+" ";
    this->block_to_send=this->block_to_send+message.toUtf8();
    sendDatatoSocket();
    //return message;
}

