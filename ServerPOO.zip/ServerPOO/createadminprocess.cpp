
#include "createadminprocess.h"
#include "QSqlQuery"
#include "textfile.h"
#include "clientinstance.h"
#include "cprotocol.h"
#include "logger.h"

#include <QStringList>
#include <QTextStream>


CreateAdminProcess::CreateAdminProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void CreateAdminProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    this->newAdmin=this->tokens[0];
    qDebug()<<this->newAdmin;
}

bool CreateAdminProcess::check_newAdmin_existence()
{
    QSqlQuery query;
    QString type;
    query.prepare("SELECT IDUtilizator FROM Conturi WHERE utilizator=:utilizator");
    query.bindValue(":utilizator",this->newAdmin);
    if(query.exec() && query.next()){
        this->newAdminId=query.value(0).toInt();
        return true;
    }
    return false;
}

void CreateAdminProcess::updateAllFolders()
{
    QString repList_path="C:/Users/Alex/Desktop/test/repository_list.txt";
    QFile rep_list(repList_path);
    if(rep_list.open(QIODevice::ReadOnly| QIODevice::Text)){
        QTextStream in(&rep_list);
        while (!in.atEnd())
        {
            QString line = in.readLine();
            TextFile *file=new TextFile(line,"trunck");
            file->addClientID(this->newAdminId);
            qDebug() << line;
        }

    }

}

void CreateAdminProcess::updateDatabase()
{
    QString noua_valoare;

    QSqlQuery interogare;
    interogare.prepare("UPDATE Conturi SET rol = :noua_valoare WHERE utilizator = :nume_utilizator");
    interogare.bindValue(":noua_valoare", "admin"); //am modificat aici pt baza mea de date
    interogare.bindValue(":nume_utilizator", this->newAdmin);
    if(!interogare.exec()){
        qDebug()<<"Eroare la actualizarea bazei de date";
    }
}

void CreateAdminProcess::run()
{
    read_from_socket();
    if(check_newAdmin_existence()){
        updateDatabase();
        updateAllFolders();
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::AdminExecuted).toUtf8();
        block_to_send=block_to_send+protocol;
        //Logger::getInstance()->write(this->username+" a initiat procesul de CreateAdmin pentru "+this->newAdmin);
    }else{
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::AdminFailed).toUtf8();
        block_to_send=block_to_send+protocol;
        //Logger::getInstance()->write("Procesul de CreateAdmin initiat de "+ this->username+" nu a fost executat");
    }

}



