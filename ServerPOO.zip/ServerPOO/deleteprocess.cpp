
#include "deleteprocess.h"
#include "textfile.h"
#include "server.h"
#include "cprotocol.h"
#include "logger.h"

#include <vector>
#include <QDir>
#include <QDataStream>
#include <QByteArray>
#include <QTextStream>

DeleteProcess::DeleteProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

QString DeleteProcess::getDirType(QString dir)
{
    QString cale="C:/Users/Alex/Desktop/test/repository_list.txt";
    QFile file(cale);
    QString line;
    if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream text(&file);
        while(!text.atEnd()){
        text>>line;
        if(line==dir)
            return "Rep";
        }
    }

    return "Branch";
}

void DeleteProcess::delete_name_from_branch()
{
    QString filePath=this->parentPath+"/branch_list.txt";
    QString s=filePath;
    QFile file(filePath);
    QStringList lines;
    if (file.open(QIODevice::ReadOnly| QIODevice::Text)){
    QTextStream stream(&file);
    while (!stream.atEnd()) {
        lines.append(stream.readLine());
    }

    lines.removeAll(this->branch);
    }
    file.resize(0);
    file.close();
    if(file.open(QIODevice::WriteOnly |QIODevice::Text)){
    QTextStream out(&file);
    for (const QString& line : lines) {
        out << line+"\n";
    }
    file.close();
    }


}


void DeleteProcess::deleteDir()
{
    //QString path="D:/POO_Proiect/FileDirectory/"+this->repository;
    QDir dir(this->path);
    if (dir.exists()) {
        if (dir.removeRecursively()) {
            // Directorul a fost sters cu succes
        } else {
            // A aparut o eroare la stergerea directorului
        }
    }
    if(this->repository!="X")
     delete_name_from_repository();
    else if(this->branch!="X")
     delete_name_from_branch();
}

void DeleteProcess::deleteFile()
{
    QFile file(this->path);
    if (file.remove()) {
        qDebug() << "Fisierul a fost sters cu succes";
    } else {
        qDebug() << "Fisierul NU a fost sters";
    }
}

void DeleteProcess::getFilesName()
{
    QStringList files=this->path.split("/");
    if(files[files.size()-1].endsWith(".txt")){
        this->file=files[files.size()-1];
        this->repository="X";
        this->branch="X";
    }else{
        QString dir=files[files.size()-1];
        if(getDirType(dir)=="Rep"){
            this->repository=dir;
            this->branch="X";
            this->file="X";
        }
        else {
            this->branch=dir;
            this->repository="X";
            this->file="X";
        }
        this->parentPath=this->parentPath+files[0];
        //iau calea pentru fisirele txt din care trebuie sa sterg numele directorului
        for(int i=1;i<files.size()-1;i++)
            this->parentPath=this->parentPath+"/"+files[i];
    }

}


void DeleteProcess::run()
{
    read_from_socket();
    //Logger::getInstance()->write(this->username+" a initiat procesul de Delete");
    if(!block_to_send.contains("NU"))
    {if(this->branch!="X" || this->repository!="X")
        deleteDir();
        else deleteFile();
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::DeleteExecuted).toUtf8();
        block_to_send=block_to_send+protocol;
        //Logger::getInstance()->write("Procesul de Delete initiat de "+ this->username+" a fost executat");
    }

}


void DeleteProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    this->path=this->tokens[0];
    if(this->path.contains("/trunk") && !this->path.contains("/trunk/"))
        block_to_send=block_to_send+"NU";
    else
    getFilesName();

}

void DeleteProcess::delete_name_from_repository()
{
    QString filePath="C:/Users/Alex/Desktop/test/repository_list.txt";
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream stream(&file);
    QStringList lines;
    while (!stream.atEnd()) {
        lines.append(stream.readLine());
    }
    lines.removeAll(this->repository);

    file.resize(0);
    file.close();
    if(file.open(QIODevice::WriteOnly|QIODevice::Text)){
    QTextStream out(&file);
    for (const QString& line : lines) {
        out << line+"\n";
    }
    file.close();}

}





