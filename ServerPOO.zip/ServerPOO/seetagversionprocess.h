#ifndef SEETAGVERSIONPROCESS_H
#define SEETAGVERSIONPROCESS_H

#include "cprocess.h"

class SeeTagVersionProcess : public CProcess
{private:
    QString repository;
    QString numeTag;
    QString idUser;
    QString versiune;
public:
    SeeTagVersionProcess(QList<QByteArray> tokens);
    void run()override;
    void read_from_socket();
    void constructMessageToSend();
};

#endif // SEETAGVERSIONPROCESS_H
