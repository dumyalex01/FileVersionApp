
#ifndef SENDBRANCHPROCESS_H
#define SENDBRANCHPROCESS_H

#include "cprocess.h"

#include <QList>
#include <QByteArray>

class SendBranchProcess : public CProcess
{
private:
    QString repositoryName;
public:
    SendBranchProcess(QList<QByteArray> tokens);
    void read_from_socket();
    void run()override;
    void getBranchList();
};

#endif // SENDBRANCHPROCESS_H
