
#ifndef CREATEPROCESS_H
#define CREATEPROCESS_H

#include "cprocess.h"
#include <QString>
#include <QTextStream>
using namespace  std;


class CreateProcess : public CProcess
{
private:
    QString repositoryName;
    QString username;

   // void addContent();
    void addId();

public:
    CreateProcess(QList<QByteArray> tokens);
    void read_from_socket();
    void run()override;
    void createRepository();
};

#endif // CREATEPROCESS_H
