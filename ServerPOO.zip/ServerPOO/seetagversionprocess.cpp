#include "seetagversionprocess.h"
#include <fstream>
#include "textfile.h"
#include <QFile>
#include <QTextStream>
using namespace std;
SeeTagVersionProcess::SeeTagVersionProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void SeeTagVersionProcess::run()
{
    read_from_socket();
    constructMessageToSend();
}

void SeeTagVersionProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    this->idUser=this->tokens[0];
    this->tokens.removeAt(0);
    this->repository=this->tokens[0];
    this->tokens.removeAt(0);
    this->numeTag=this->tokens[0];
    this->tokens.removeAt(0);
    this->versiune=this->tokens[0];
    this->tokens.removeAt(0);
}

void SeeTagVersionProcess::constructMessageToSend()
{
    QString path="C:/Users/Alex/Desktop/test/"+ this->repository+"/"+this->numeTag+"/"+this->versiune;
    QFile file(path);
    TextFile A(this->repository,"trunk");
    if(!A.check_access(this->idUser.toInt()))
        block_to_send+="NO_ACCESS";
    else
    {
    if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream text(&file);
        while(!text.atEnd()){
            QString line = text.readLine();
            line.append("\n");
            block_to_send+=line.toUtf8();
        }
    }
    else block_to_send="NU";
    }
    sendDatatoSocket();
}
