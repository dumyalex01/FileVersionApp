
#ifndef COMMITPROCESS_H
#define COMMITPROCESS_H
#include "textfile.h"
#include "cprocess.h"

#include <QList>
#include <QByteArray>

class CommitProcess : public CProcess
{
    TextFile *file;
    QString repositoryName;
    QString branchName;
    QString version;
    QByteArrayList content;
    void getFiles(QString path);
   // int version;
public:
    CommitProcess(QList<QByteArray> tokens);
    void run()override;
    void read_from_socket();
    void addNewVersion();
    bool check_for_changes();

};

#endif // COMMITPROCESS_H
