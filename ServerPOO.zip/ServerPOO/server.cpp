
#include "server.h"
#include "processfactory.h"

#include <QDebug>
#include <QDir>
#include <QFile>
#include <QCoreApplication>
#include <QTcpSocket>
#include <QStringList>
#include <QDataStream>
#include <QSqlQuery>


Server* Server::instance=nullptr;

Server::Server()
{
    this->ClientCounter=0;
    QSqlDatabase baza;
    baza=QSqlDatabase::addDatabase("QODBC");
    baza.setDatabaseName("Driver={SQL Server};Server=DESKTOP-O344N69;Database=BazaConturi;Trusted_Connection=yes;");
    if(!baza.open())
        qDebug()<<"Probleme la baza de date!";
    this->db=baza;

    QSqlQuery query;
    query.prepare("SELECT IDUtilizator FROM Conturi WHERE rol = 'admin'");
    if (query.exec()) {
    while (query.next()) {
        this->Admins.append(query.value(0).toString());

    }

    }

}

Server::Server(const Server &obj ){
    this->ClientCounter=obj.ClientCounter;
    //this->db=BazaDeDate::getInstance();

}

Server* Server::getInstance(){
    if(Server::instance==nullptr){
        instance=new Server();
    }
    return Server::instance;
}

void Server::StartServer(int port_number){


     //Create utilities
     createUtilities();


    if(server.listen(QHostAddress::LocalHost,port_number))
    {

    // se realizeaza conexiunea

    connect(&server, &QTcpServer::newConnection, [&]() {
    QTcpSocket* socket = server.nextPendingConnection();

    if (socket) {
        qDebug() << "New client connected!";
        if (socket->waitForReadyRead(30000)) {


        //in.setVersion(QDataStream::Qt_6_2);
        QByteArray data=socket->readAll();
        QByteArrayList in;
        if(QString::fromUtf8(data)[0]=='4')
            in=getCode(data,'~');
        else
            in=getCode(data,' ');
        qDebug() << "Received data from client: ";
        qDebug()<< data;
        IProcess *process=ProcessFactory::getAction(in[0],in);
        process->run();
        socket->write(process->sendDatatoSocket());

        }
        if(socket->waitForBytesWritten()){
        socket->disconnectFromHost();}
        qDebug() << "Client disconnected!";
    } else {
        qDebug() << "Error: Failed to get next pending connection!";
    }
     });
    }
    else
    {
        qInfo("Server could not open.");
    }
}

int Server::giveID(QString username)
{

//    int id;
//    QSqlQuery query;
//    query.prepare("SELECT UserId FROM Users WHERE username = :username");
//    query.bindValue(":username", QVariant(username));
//    if (!query.exec()) {
//        qDebug() << "Eroare la executarea query-ului.";
//    }
//    while (query.next()) {
//         id = query.value(0).toInt();
//    }
//    return id;
    for(int i=0;i<this->usersID.size();i++){
        if(usersID[i].second==username)
        return usersID[i].first.toInt();
    }

}

void Server::createUtilities()
{
    QDir directory;
    QString path="C:/Users/Alex/Desktop/test";
    if(!directory.exists(path)){ //verificam daca exista
        if(directory.mkdir(path)) {//Daca nu exista il creem;
            QString path_file="C:/Users/Alex/Desktop/test/access_file.txt";
            QFile access_file(path_file);
            if(access_file.open(QIODevice::ReadWrite | QIODevice::Text)){
                access_file.close();
            }else{
                qDebug()<<"Eroare la deschiderea fisierului de acces";
            }

            QString rep_path="C:/Users/Alex/Desktop/test/repository_list.txt";
            QFile rep_list(rep_path);
            if(rep_list.open(QIODevice::ReadOnly|QIODevice::Text)){
                rep_list.close();
            }

            QString logg_path="C:/Users/Alex/Desktop/test/logger.txt";
            QFile logger_file(logg_path);
            if(logger_file.open(QIODevice::ReadWrite| QIODevice::Text)){
                logger_file.close();
            }
        }
    }
    getUsersId();
}

QList<QByteArray> Server::getCode(QByteArray message,char sep)
{
    QList<QByteArray> tokens = message.split(sep);
    return tokens;

}

void Server::getUsersId()
{
    QSqlQuery query;
    query.prepare("SELECT * FROM Conturi");
    query.exec();
    while(query.next())
    {
        QString ID=query.value(0).toString();
        QString User=query.value(1).toString();
        pair<QString,QString> pereche;
        pereche.first=ID;
        pereche.second=User;
        usersID.push_back(pereche);
    }
}



