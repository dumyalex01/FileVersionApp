#include "giveaccessprocess.h"
#include "cprotocol.h"
#include "server.h"

#include <QFile>
#include "textfile.h"
#include <QDebug>
GiveAccessProcess::GiveAccessProcess(QByteArrayList tokens):CProcess(tokens)
{
}

void GiveAccessProcess::read_from_socket()
{
    this->tokens.removeFirst();
    this->repository=this->tokens[0];
    this->tokens.removeFirst();
    this->user=this->tokens[0];
    this->UsersID=Server::getInstance()->getNameID();
    qDebug()<<user;

}

void GiveAccessProcess::run()
{
    read_from_socket();
    QString currentID;
    bool userGasit=0;
    for(int i=0;i<UsersID.size();i++)
        if(this->UsersID[i].second==this->user)
        { qDebug()<<UsersID[i].second;
        currentID=this->UsersID[i].first;
            userGasit=1;
            break;
        }
    if(userGasit==0){
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::UserNotFound).toUtf8();
        block_to_send=block_to_send+protocol;
        //return "-1";
    }
    else
   {
        TextFile A(this->repository,"trunk");
        if(!A.check_access(currentID.toInt()))
        { A.addClientID(currentID.toInt());
            QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::AccessGiven).toUtf8();
            block_to_send=block_to_send+protocol;
        }
        else{
            QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::AccessRestricted).toUtf8();
            block_to_send=block_to_send+protocol;
        }

    }
    sendDatatoSocket();
}


