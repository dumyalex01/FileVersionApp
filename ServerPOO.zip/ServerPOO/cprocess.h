
#ifndef CPROCESS_H
#define CPROCESS_H

#include "iprocess.h"
#include <QRunnable>
#include <QList>
#include <QByteArray>

class CProcess : public IProcess
{
protected:
    QString username;
    QString password;
    QList<QByteArray> tokens;
    QByteArray block_to_send="";
    int clientID;
public:
    CProcess(QList<QByteArray> tokens);
    void setUser(QString user){ this->username=user;};
    void setPassword(QString password){this->password=password;};
    QByteArray sendDatatoSocket()override {return this->block_to_send;};

};

#endif // CPROCESS_H
