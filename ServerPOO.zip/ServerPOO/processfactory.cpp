
#include "processfactory.h"

#include "seetagversionprocess.h"
ProcessFactory::ProcessFactory()
{

}

IProcess *ProcessFactory::getAction(QString code, QList<QByteArray> tokens)
{
    ProtocolsToReceive protocol=CProtocol::getInstance()->getProtocoltoReceive(code);
    if(protocol==ProtocolsToReceive::Authentification){
        return new AuthentificationProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::BranchFile){
        return new BranchProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::SendBranch){
        return new SendBranchProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::CommitFile){
        return new CommitProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::SendCommitFile){
        return new SendCommitFileProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::SendRepository){
        return new SendRepositoryProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::Registration){
        return new loginProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::ViewFile){
        return new ViewProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::Properties){
        return new Properties(tokens);
    }
    if(protocol==ProtocolsToReceive::GiveAcess){
        return new GiveAccessProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::GiveAdmin){
        return new CreateAdminProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::Create){
        return new CreateProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::Merge){
        return new MergeProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::UsersDetails){
        return new GetUserProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::Delete){
        return new DeleteProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::SendVersions){
        return new SendVersionsProcess(tokens);
    }

    if(protocol==ProtocolsToReceive::Help){
        return new HelpProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::Tag){
        return new TagProcess(tokens);
    }
    if(protocol==ProtocolsToReceive::SeeTagVersion)
    {
        return new SeeTagVersionProcess(tokens);
    }

}

