
#include "createprocess.h"
#include "server.h"
#include "cprotocol.h"
#include "textfile.h"
#include "logger.h"

#include <QByteArray>
#include <QBuffer>
#include <QFile>

//void CreateProcess::addContent()
//{
//    QString path="D:/POO_Proiect/FileDirectory/"+this->repositoryName+"/trunck/"+this->repositoryName+"_1.txt";
//    QFile file(path);
//    if(file.open(QIODevice::WriteOnly | QIODevice::Text)){
//        QTextStream out(&file);
//        out<<"TAG:"+username+" commited this file";
//        for(auto it=this->tokens.begin();it!=this->tokens.end();it++){
//            QString line=QString::fromUtf8(*it);
//            out<<line+"\n";
//        }
//        file.close();
//    }else {
//        qDebug()<<"Eroare la deschiderea primei versiune";
//    }
//}

void CreateProcess::addId()
{
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->repositoryName+"_access.txt";
    QFile accessFile(path);
    if(accessFile.open(QIODevice::ReadWrite|QIODevice::Append)){
        QTextStream text(&accessFile);


        bool isAdmin=false;   //verific daca este admin pentru a nu l trece inca o data
        QStringList admins=Server::getInstance()->getAdmins();
        for(int i=0;i<admins.size();i++)
            if(QString::number(this->clientID)==admins[i])
                isAdmin=true;
        if(!isAdmin)
            text<<QString::number(this->clientID);

        //pun si id-urile adminnilor
      /*  QStringList admins=Server::getInstance()->getAdmins();
        for(int i=0;i<admins.size();i++)
        {   text<<"\n";
            text<<admins[i];
        }*/

        accessFile.close();
    }

}

CreateProcess::CreateProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void CreateProcess::read_from_socket()
{
    this->username=this->tokens[1];
    this->repositoryName=this->tokens[2];
    this->tokens.removeAt(0);
    this->tokens.removeAt(0);
    this->tokens.removeAt(0);
    this->clientID=Server::getInstance()->giveID(this->username);

}

void CreateProcess::run()
{
    read_from_socket();
   // Logger::getInstance()->write(this->username+" a initiat procesul de Create");
    QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::CreateExecuted).toUtf8();
    block_to_send=block_to_send+protocol;
    createRepository();
   // Logger::getInstance()->write("Procesul de Create initiat de "+ this->username+" a fost executat");

}

void CreateProcess::createRepository()
{
    TextFile* newFile=new TextFile(this->repositoryName,"trunk");
    //Am creat directorul si toate fisierele aferente;
   // addContent();
    addId();


}


