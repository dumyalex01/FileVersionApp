
#include "helpprocess.h"
#include <QFile>

HelpProcess::HelpProcess(QByteArrayList tokens):CProcess(tokens)
{

}

void HelpProcess::run()
{

    QString path="C:/Users/Alex/Desktop/test/help.txt";
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return;
    }
    else
    {
        while(!f.atEnd())
        {
            QByteArray text=f.readLine();
            this->block_to_send+=text;
        }
    }
    sendDatatoSocket();
}

