
#include "bazadedate.h"
#include <QSqlQuery>
BazaDeDate* BazaDeDate::instance=nullptr;
BazaDeDate::BazaDeDate()
{
    this->db=QSqlDatabase::addDatabase("QODBC");
    this->db.setDatabaseName("Driver={SQL Server};Server=DESKTOP-O344N69;Database=BazaConturi;Trusted_Connection=yes;");
}

BazaDeDate *BazaDeDate::getInstance()
{
    if(instance==nullptr){
        instance=new BazaDeDate();
    }
    return instance;
}

bool BazaDeDate::checkCredentials(QString username, QString password)
{
    if(db.open()){
        QSqlQuery qry;
       if(qry.exec("select * from Conturi")){
             while(qry.next()){
                if(username==qry.value(1) && password==qry.value(2))
                     return true;
               }
           }
           else return false;
      }else qDebug()<<"Nu s-a putut conecta la baza de date";

}

