#include "tagprocess.h"
#include <QDir>
#include <QFile>
#include "cprotocol.h"


TagProcess::TagProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void TagProcess::run()
{
    read_from_socket();
    copyDirectoryRecursively();

}

void TagProcess::copyDirectoryRecursively()
{
    QString pathSource="C:/Users/Alex/Desktop/test/"+ this->repository+"/"+this->branch;
    QString pathDestination="C:/Users/Alex/Desktop/test/"+this->repository+"/"+this->tagName+".tag";
    QDir branchToCopy(pathSource);
    QDir tag(pathDestination);
    if(!tag.exists())
       { tag.mkpath(pathDestination);
    QStringList files = branchToCopy.entryList(QDir::Files | QDir::NoDotAndDotDot);

        for (const QString &file : files) {
            QString sourceFile = pathSource + "/" + file;
            QString destinationFile = pathDestination + "/" + file;
            QFile::copy(sourceFile, destinationFile);
        }
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::TagExecuted).toUtf8();
        block_to_send=block_to_send+protocol;
        sendDatatoSocket();
    }
    else
    {
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::TagFailed).toUtf8();
        block_to_send=block_to_send+protocol;
        sendDatatoSocket();
    }


}

void TagProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    this->repository=tokens.at(0);
    this->tokens.removeAt(0);
    this->branch=tokens.at(0);
    this->tokens.removeAt(0);
    this->tagName=tokens.at(0);
    this->tokens.removeAt(0);
}
