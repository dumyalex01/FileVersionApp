
#ifndef CFILE_H
#define CFILE_H

#include "ifile.h"



class CFile : public IFile
{
protected:
    //
    QString repositoryName;
    QString branchName;

public:
    CFile();
    CFile(QString filename, QString fileParent);
    QString getFilename()override {return this->repositoryName;};


};

#endif // CFILE_H
