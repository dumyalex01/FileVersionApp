
#ifndef USERDETAILSPROCESS_H
#define USERDETAILSPROCESS_H

#include "cprocess.h"



class UserDetailsProcess : public CProcess
{
public:
    UserDetailsProcess();
    void run() override;
};

#endif // USERDETAILSPROCESS_H
