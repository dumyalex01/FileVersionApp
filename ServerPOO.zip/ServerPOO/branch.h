
#ifndef BRANCH_H
#define BRANCH_H

#include "cfile.h"
#include <vector>
#include <QStringList>
using namespace std;

class Branch : public CFile
{
private:
    vector<QString> versions;
    int versionsNumber;
public:
    Branch(QString filename, QString fileParent);
    int getVersionNumber() {return this->versionsNumber;};
    QStringList getContent(QString filename);
    QString getFirstFile();

};

#endif // BRANCH_H
