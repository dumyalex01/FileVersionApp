
#ifndef BAZADEDATE_H
#define BAZADEDATE_H
#include <QObject>
#include <QSqlDatabase>


class BazaDeDate:public QObject
{
    Q_OBJECT
private:
    static BazaDeDate* instance;
    BazaDeDate();
    QSqlDatabase db;
public:
   static BazaDeDate* getInstance();
    bool checkCredentials(QString user, QString password);
};

#endif // BAZADEDATE_H
