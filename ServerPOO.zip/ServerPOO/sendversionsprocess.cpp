
#include "sendversionsprocess.h"
#include "server.h"
#include "cprotocol.h"
#include "logger.h"

#include <QFile>
#include <QDir>
#include <QFileInfo>

void SendVersionsProcess::getRepBranCH(QString path)
{
    QStringList dirs=path.split("/");
    this->repositoryName=dirs[dirs.size()-2];
    this->branchName=dirs[dirs.size()-1];

}

SendVersionsProcess::SendVersionsProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void SendVersionsProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    QString path=this->tokens[0];
    //this->repositoryName=this->tokens[0];
    getRepBranCH(path);

    //this->branchName=this->tokens[0];
}

void SendVersionsProcess::getVersionList()
{
    int nr=0;
    QString lines;
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName;
    qDebug()<<path;
    //Deschid lista de fisiere
    QDir branch_dir(path);
    if(branch_dir.exists(path)){
        //QStringList list=branch_dir.entryList();
        QFileInfoList list = branch_dir.entryInfoList();
        //QFileInfo file;
        for (int i=0;i<list.size();i++) {
            if (list[i].suffix() == "txt") {
                nr++;
                lines+=list[i].fileName()+" ";
            }


//        for(int it=0; it!=list.size();it++){
//            if(list[it].contains(this->repositoryName)){
//                nr++;
//                lines+=list[it]+" ";
//                //QByteArray buff=list[it].toUtf8();
//                //this->block_to_send=this->block_to_send+buff+" ";
//            }
        }

    }
    QString number=QString::number(nr);
    this->block_to_send=this->block_to_send+number.toUtf8()+" "+lines.toUtf8();
}

void SendVersionsProcess::run()
{
    read_from_socket();
    Logger::getInstance()->write(this->username+" a initiat procesul de SendVersionList");
   // QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::VersionsList).toUtf8();
    //block_to_send=block_to_send+protocol+" ";
    getVersionList();
   // Logger::getInstance()->write("Procesul de SendVersionLits initiat de "+this->username+" a fost executat");

}

