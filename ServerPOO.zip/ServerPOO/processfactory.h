
#ifndef PROCESSFACTORY_H
#define PROCESSFACTORY_H

#include "cprotocol.h"
#include "branchprocess.h"
#include "commitprocess.h"
#include "createadminprocess.h"
#include "createprocess.h"
#include "deleteprocess.h"
#include "loginprocess.h"
#include "sendbranchprocess.h"
#include "sendrepositoryprocess.h"
#include "sendversionsprocess.h"
#include "sendcommitfileprocess.h"
#include "authentificationprocess.h"
#include "viewprocess.h"
#include "giveaccessprocess.h"
#include "getuserprocess.h"
#include "properties.h"
#include "mergeprocess.h"
#include "helpprocess.h"
#include "tagprocess.h"
#include <QString>
#include <QByteArray>
#include <QList>

class ProcessFactory
{

public:
    ProcessFactory();
    static IProcess* getAction(QString code, QList<QByteArray> tokens);
};

#endif // PROCESSFACTORY_H
