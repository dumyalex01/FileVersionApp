
#include "branchprocess.h"
#include "textfile.h"
#include "cprotocol.h"
#include "server.h"
#include "logger.h"

#include <vector>
#include <QDataStream>
#include <QDir>
#include <QFile>
#include <QByteArray>
#include <QTextStream>
#include <QDateTime>
#include <QStringList>
BranchProcess::BranchProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void BranchProcess::read_from_socket()
{

    this->repository=this->tokens[1];
    this->branch=this->tokens[2];
    this->version=this->tokens[3];
    this->newBranchName=this->tokens[4];

    //this->version=this->tokens[4].toInt();
}

void BranchProcess::create_branch()
{
    Branch *branch=new Branch(this->repository,this->newBranchName);
    copyFile();
    if(branch!=nullptr)
        delete branch;
}

void BranchProcess::copyFile()
{
    //QString version=QString::number(this->version);
    QString sourceFile_path="C:/Users/Alex/Desktop/test/"+this->repository+"/"+this->branch+"/"+this->version;  //nu trunk!
    QString filev=getVersionName(sourceFile_path);
    QString branchFile_path="C:/Users/Alex/Desktop/test/"+this->repository+"/"+this->newBranchName+"/"+this->repository+"_"+this->newBranchName+"_"+filev;

    QFile sourceFile(sourceFile_path);
    QFile branchFile(branchFile_path);
    if (!sourceFile.open(QIODevice::ReadOnly) || !branchFile.open(QIODevice::WriteOnly))
       { qDebug()<<"Eroare la deschiderea fisierelor din noul branch creat";
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::BranchFailed).toUtf8();
    block_to_send=block_to_send+protocol;}

    // Copiază datele din fișierul sursă în fișierul de destinație
    QByteArray data = sourceFile.readAll();
    QDateTime currentDataTime=QDateTime::currentDateTime();
    QString currentDateTimeString=currentDataTime.toString(Qt::ISODate);
    QByteArray content="This file was changed at->"+currentDateTimeString.toUtf8();
    /*int i=0;
    while(data[i]!='\n')
    {
      data.removeFirst();
    }
    content.append(data);*/
    branchFile.write(data);

    sourceFile.close();
    branchFile.close();
    QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::BranchExecuted).toUtf8();
    block_to_send=block_to_send+protocol;
}

QString BranchProcess::getVersionName(QString version)
{
    QStringList list=version.split("_");
    return list[list.size()-1];
}

void BranchProcess::run()
{
    read_from_socket();
        create_branch();


}



