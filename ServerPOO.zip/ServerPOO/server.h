#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QVector>
#include <QCoreApplication>
#include <QSqlDatabase>
#include "bazadedate.h"
#include "clientinstance.h"
#include <QMap>
#include <QString>
#include <QByteArray>
#include <QList>
#include <vector>
using namespace std;

class Server : public QTcpServer
{
    Q_OBJECT
private:
    int ClientCounter;
    QSqlDatabase db;
    Server();
    Server(const Server &obj);
    static Server* instance;
    QTcpServer server;
    vector<pair<QString,QString>> usersID;
    QStringList Admins;

public:
    static Server* getInstance();
    void StartServer(int portnumber);
    int giveID(QString username);
    void createUtilities();
    QList<QByteArray> getCode(QByteArray message,char sep=' ');
    void getUsersId();
    vector<pair<QString,QString>> getNameID(){return this->usersID;};
    QStringList getAdmins(){return this->Admins;};

};

#endif // SERVER_H
