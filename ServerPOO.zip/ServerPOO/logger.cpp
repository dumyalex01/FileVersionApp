
#include "logger.h"
Logger* Logger::Instance=nullptr;
QString Logger::path="C:/Users/Alex/Desktop/test/logger.txt";
Logger::Logger()
{

}

QString Logger::setMessage(QString message)
{
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString currentDateTimeString = currentDateTime.toString(Qt::ISODate);
    message=message+"-------------"+currentDateTimeString;
    return message;
}

Logger *Logger::getInstance()
{
    if(Instance==nullptr){
        Instance=new Logger();
    }
    return Instance;
}

void Logger::write(const QString &message)
{
    QFile file(path);
    if (file.open(QIODevice::WriteOnly | QIODevice::Append)) {
        QTextStream stream(&file);
        stream << setMessage(message) <<"\n";
        file.close();
    }
}

