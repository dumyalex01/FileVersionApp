
#include "sendrepositoryprocess.h"
#include "server.h"
#include "textfile.h"
#include "cprotocol.h"
#include "logger.h"

#include <QString>
#include <QFile>


SendRepositoryProcess::SendRepositoryProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void SendRepositoryProcess::run()
{
    read_from_socket();
   // Logger::getInstance()->write(" a initiat procesul de SendRepositoryList");
    //QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::RepositoryList).toUtf8();
    //block_to_send=block_to_send+protocol+" ";
    getRepList();
    //Logger::getInstance()->write("Procesul de SendRepositoryList initiat de "+ this->username+" a fost executat");
}

void SendRepositoryProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    //his->username=tokens[0];
   // this->tokens.removeAt(0);
    this->clientID=(tokens[0]).toInt();
    //this->clientID=Server::getInstance()->giveID(this->username);
}

void SendRepositoryProcess::getRepList()
{
    QString repList;
    int nr=0;
    QString path="C:/Users/Alex/Desktop/test/repository_list.txt";
    QFile file(path);
    //Deschid lista de fisiere
    if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream text(&file);
        while(!text.atEnd()){
            QString line = text.readLine();
            //Iau fiecare fisier in parte si vad daca contine id-ul clientului;
            TextFile *file=new TextFile(line,"trunk");
            if(file->check_access(this->clientID)){
                //QByteArray buff;
                //buff=line.toUtf8();
                repList=repList+line+" ";
                nr++;
            }
        }
    }

    QString number=QString::number(nr);
    this->block_to_send =this->block_to_send+number.toUtf8()+" " +repList.toUtf8();
}


