
#include "mergeprocess.h"
#include "logger.h"
#include "branch.h"
#include "cprotocol.h"
#include "textfile.h"

#include <QDateTime>
#include <QStringList>

QString MergeProcess::getOriginal(QString filename)
{
    QStringList list=filename.split("_");
    return list[list.size()-1];
}

MergeProcess::MergeProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void MergeProcess::read_from_socket()
{
    this->tokens.removeFirst();
    this->repositoryName=tokens[0];
    this->tokens.removeAt(0);
    this->branch1=tokens[0];
    this->tokens.removeFirst();
    this->file1=tokens[0];
    this->tokens.removeFirst();
    this->branch2=tokens[0];
    this->tokens.removeFirst();
    this->file2=tokens[0];

}

void MergeProcess::run()
{
    read_from_socket();
    if(check_with_original()){
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::BranchExecuted).toUtf8();
        block_to_send=block_to_send+protocol;
        merge();

    }else {

        //Send message

    }

}

void MergeProcess::merge()
{
    Branch *branch1=new Branch(this->repositoryName,this->branch1);
    Branch *branch2=new Branch(this->repositoryName,this->branch2);
    Branch *trunck=new Branch(this->repositoryName,"trunk");
    QString originalVersion=this->repositoryName+"_"+"trunk_"+getOriginal(branch1->getFirstFile());
    QStringList originalFile=trunck->getContent(originalVersion);
    QStringList branch1File=branch1->getContent(branch1->getFirstFile());
    QStringList branch2File=branch2->getContent(branch2->getFirstFile());
    QStringList newFile;
    //newFile=originalFile;
    int min;
    int mostrecent=check_most_recent(get_date_from_string(branch1File[0]), get_date_from_string(branch2File[0]));

    originalFile.removeAt(0);// ca sa scap de linia de tag
    branch1File.removeAt(0);
    branch2File.removeAt(0);
    min=branch2File.length();
    int i;
    for(i=0;i<originalFile.size();i++){
        if(originalFile[i]!=branch1File[i] && originalFile[i]!=branch2File[i]){
            if(mostrecent==1)
                newFile.append(branch1File[i]);
            else newFile.append(branch2File[i]+"\n");
        }

    }
    if(mostrecent==2){

        for(i=originalFile.size();i<branch2File.size()-2;i++) //-1 pt return;
            newFile.append(branch2File[i]+"\n");
        for(i=originalFile.size()-2;i<branch1File.size();i++)
            newFile.append(branch1File[i]+"\n");
    }else{

        for(i=originalFile.size();i<branch1File.size()-2;i++)
            newFile.append(branch1File[i]+"\n");
        for(i=originalFile.size()-2;i<branch2File.size();i++)
            newFile.append(branch2File[i]+"\n");
    }
    TextFile file(this->repositoryName,"trunk");
    file.addFile(newFile,this->username);
}

bool MergeProcess::check_with_original()
{
    Branch *branch1=new Branch(this->repositoryName,this->branch1);
    Branch *branch2=new Branch(this->repositoryName,this->branch2);
    Branch *trunck=new Branch(this->repositoryName,"trunk");
    QString originalVersion=this->repositoryName+"_"+"trunk_"+getOriginal(branch1->getFirstFile());
    QStringList originalFile=trunck->getContent(originalVersion);
    QStringList branch1File=branch1->getContent(branch1->getFirstFile());
    QStringList branch2File=branch2->getContent(branch2->getFirstFile());
    qDebug()<<originalFile.size()<<"\n";
    qDebug()<<branch1File.size()<<"\n";
    qDebug()<<branch2File.size()<<"\n";


    if(originalFile.size()>branch1File.size() || originalFile.size()>branch2File.size())
        return false;
    else return true;
}

QDateTime MergeProcess::get_date_from_string(QString line)
{
    QString dateString;
    for (int i=0;i<line.size();i++) {
        if(line[i]=='-' && line[i+1]=='>'){
            i+=2;
            while(i<line.size() && line[i]!='\n'){
                dateString.append(line[i]);
                    i++;
            }
            QDateTime dateTime1 = QDateTime::fromString(dateString);
            return dateTime1;
        }
    }
}

int MergeProcess::check_most_recent(QDateTime date1, QDateTime date2)
{
  QDateTime mostRecentDateTime = QDateTime::fromMSecsSinceEpoch(qMax(date1.toMSecsSinceEpoch(), date2.toMSecsSinceEpoch()));
  if(mostRecentDateTime==date1)
      return 1;
  return 2;
}


