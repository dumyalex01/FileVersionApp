
#ifndef IPROTOCOL_H
#define IPROTOCOL_H




class IProtocol
{
public:
    IProtocol();
};

#endif // IPROTOCOL_H
