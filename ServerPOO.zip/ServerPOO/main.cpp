
#include <QCoreApplication>
#include "server.h"
#include "branch.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int port_number=1234;
    Server::getInstance()->StartServer(port_number);
    return a.exec();
}
