
#ifndef CREATEADMINPROCESS_H
#define CREATEADMINPROCESS_H

#include "cprocess.h"
#include <QString>



class CreateAdminProcess : public CProcess
{
private:
    //QString AdminName;
    QString newAdmin;
    int AdminId;
    int newAdminId;

public:
    CreateAdminProcess(QList<QByteArray> tokens);
    void read_from_socket();
    bool check_newAdmin_existence();
    void updateAllFolders();
    void updateDatabase();
    void run()override;
};

#endif // CREATEADMINPROCESS_H
