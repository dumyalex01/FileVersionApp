
#include "cprotocol.h"

CProtocol* CProtocol::Instance=nullptr;

CProtocol::CProtocol()
{
    this->AvailableProtocolsToReceive.insert("2",ProtocolsToReceive::Authentification);
    this->AvailableProtocolsToReceive.insert("1",ProtocolsToReceive::Registration);
    this->AvailableProtocolsToReceive.insert("4",ProtocolsToReceive::CommitFile);
    this->AvailableProtocolsToReceive.insert("3",ProtocolsToReceive::BranchFile);
    this->AvailableProtocolsToReceive.insert("12",ProtocolsToReceive::ViewFile);
    this->AvailableProtocolsToReceive.insert("9",ProtocolsToReceive::Properties);
    this->AvailableProtocolsToReceive.insert("17",ProtocolsToReceive::GiveAcess);
    this->AvailableProtocolsToReceive.insert("6",ProtocolsToReceive::GiveAdmin);
    this->AvailableProtocolsToReceive.insert("8",ProtocolsToReceive::Merge);
    this->AvailableProtocolsToReceive.insert("10",ProtocolsToReceive::UsersDetails);
    this->AvailableProtocolsToReceive.insert("5",ProtocolsToReceive::Delete);
    this->AvailableProtocolsToReceive.insert("13",ProtocolsToReceive::SendRepository);
    this->AvailableProtocolsToReceive.insert("14",ProtocolsToReceive::SendBranch);
    this->AvailableProtocolsToReceive.insert("15",ProtocolsToReceive::SendVersions);
    this->AvailableProtocolsToReceive.insert("16",ProtocolsToReceive::SendCommitFile);
    this->AvailableProtocolsToReceive.insert("18",ProtocolsToReceive::Create);
    this->AvailableProtocolsToReceive.insert("19",ProtocolsToReceive::Help);
    this->AvailableProtocolsToReceive.insert("20",ProtocolsToReceive::Tag);
    this->AvailableProtocolsToReceive.insert("21",ProtocolsToReceive::SeeTagVersion);


    this->AvailableProtocolsToSend.insert(ProtocolsToSend::ValidCredentials,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::InvalidCredentials,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::FoundRegistration,"EXISTA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::NotfoundRegistration,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::NotLog,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::AccessGiven,"1");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::AccessRestricted,"-2");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::UserNotFound,"-1");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::CommitExecuted,"7");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::CommitFailed,"8");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::ViewExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::ViewFailed,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::PropertiesExecuted,"1");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::PropertiesFailed,"-1");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::MergeFailed,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::MergeExecuted,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::DeleteExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::DeleteFailed,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::AdminExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::AdminFailed,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::BranchExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::BranchFailed,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::SendDetails,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::RepositoryList,"");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::BranchList,"");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::VersionsList,"");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::SendFile,"");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::CreateExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::TagExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::TagFailed,"NU");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::SeeTagExecuted,"DA");
    this->AvailableProtocolsToSend.insert(ProtocolsToSend::SeeTagFailed,"NU");

}

CProtocol *CProtocol::getInstance()
{
    if(Instance==nullptr){
        Instance=new CProtocol();
    }
    return Instance;
}

bool CProtocol::checkforprotocol(QString protocol)
{
    return this->AvailableProtocolsToReceive.contains(protocol);
}

ProtocolsToReceive CProtocol::getProtocoltoReceive(QString protocol)
{
    if(this->AvailableProtocolsToReceive.contains(protocol))
        return this->AvailableProtocolsToReceive.value(protocol);
}

QString CProtocol::getProtocoltoSend(ProtocolsToSend protocol)
{
    if(this->AvailableProtocolsToSend.contains(protocol))
        return this->AvailableProtocolsToSend.value(protocol);
}

