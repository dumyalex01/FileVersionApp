
#ifndef BRANCHPROCESS_H
#define BRANCHPROCESS_H

#include "cprocess.h"
#include "branch.h"
#include <QString>


class BranchProcess : public CProcess
{
private:
   // Branch* newBranch;
    QString repository;
    QString newBranchName;
    QString branch;
    QString version;
    void create_branch();
    void copyFile();
    QString getVersionName(QString version);
public:
    BranchProcess(QList<QByteArray> tokens);
    void read_from_socket();
    bool check_for_access(int clientID);
    void run()override;


};

#endif // BRANCHPROCESS_H
