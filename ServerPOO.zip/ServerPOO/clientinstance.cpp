
#include "clientinstance.h"


ClientInstance::ClientInstance(QObject *parent)
    : QObject{parent}
{
 QThreadPool::globalInstance()->setMaxThreadCount(10);
}

void ClientInstance::setSocket(int Descriptor)
{
    socket=new QTcpSocket(this);
    //socket = new QTcpSocket(this);
    socket->setSocketDescriptor(Descriptor);

    socketDescriptor=Descriptor;
}

void ClientInstance::readyRead()
{
    QDataStream in=socket->readAll();
    in.setVersion(QDataStream::Qt_6_2);
    QByteArray data;
    in>>data;
    do{

    }while(in.commitTransaction());
}

void ClientInstance::write(QByteArray block_to_send)
{
   // socket->write(block_to_send);
    if (socket->write(block_to_send) == -1) {
        qDebug() << "Write error: " ;
    }
    socket->flush();
    qDebug()<<socket->errorString();
    socket->waitForBytesWritten();
}

void ClientInstance::disconnected()
{
    emit clientDisconnected();
}

void ClientInstance::connected()
{
        qDebug()<<"Connected";
}

