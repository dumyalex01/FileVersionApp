
#ifndef GIVEACCESSPROCESS_H
#define GIVEACCESSPROCESS_H

#include "cprocess.h"

#include <QByteArrayList>>

//#include <vector>
using namespace std;
class GiveAccessProcess : public CProcess
{
public:
    GiveAccessProcess(QByteArrayList tokens);
    void run() override;
    void read_from_socket();
private:
    QString user;
    QString repository;
    vector<pair<QString,QString>> UsersID;
};

#endif // GIVEACCESSPROCESS_H
