
//#ifndef CPROTOCOL_H
//#define CPROTOCOL_H

#include <QString>
#include <QMap>
using namespace std;

enum class ProtocolsToSend{
    ValidCredentials,
    InvalidCredentials,
    FoundRegistration,
    NotfoundRegistration,
    NotLog,
    SendFile,
    AccessGiven,
    AccessRestricted,
    UserNotFound,
    CommitExecuted,
    CommitFailed,
    BranchExecuted,
    BranchFailed,
    ViewExecuted,
    ViewFailed,
    PropertiesExecuted,
    PropertiesFailed,
    MergeExecuted,
    MergeFailed,
    DeleteExecuted,
    DeleteFailed,
    AdminFailed,
    AdminExecuted,
    SendDetails,
    RepositoryList,
    BranchList,
    VersionsList,
    SendVersionFile,
    CreateExecuted,
    TagExecuted,
    TagFailed,
    SeeTagFailed,
    SeeTagExecuted

};

enum class ProtocolsToReceive{
    Authentification,
    Registration,
    CommitFile,
    BranchFile,
    ViewFile,
    Properties,
    GiveAcess,
    GiveAdmin,
    Create,
    Merge,
    UsersDetails,
    Delete,
    SendRepository,
    SendBranch,
    SendVersions,
    SendCommitFile,
    Help,
    Tag,
    SeeTagVersion
};


class CProtocol
{
private:
    QMap<QString, ProtocolsToReceive> AvailableProtocolsToReceive;
    QMap<ProtocolsToSend,QString> AvailableProtocolsToSend;
    static CProtocol* Instance;
    CProtocol();
public:
   static CProtocol* getInstance();
    bool checkforprotocol(QString protocol);
    ProtocolsToReceive getProtocoltoReceive(QString protocol);
    QString getProtocoltoSend(ProtocolsToSend protocol);

};

//#endif // CPROTOCOL_H
