
#ifndef TEXTFILE_H
#define TEXTFILE_H

#include "cfile.h"

#include <vector>
#include <QFile>
#include <QList>
#include <QByteArray>


//REPOSITORY
class TextFile : public CFile
{
private:
    int branches;
public:
    TextFile(QString repository, QString branch);
    vector<QString> getBranchesName(QString branch);
    bool check_access(int ClientID);
    void addClientID(int ClientID);
    void addFile(QList<QByteArray> tokens, QString username);
    void addFile(QStringList newFile, QString username);

};

#endif // TEXTFILE_H
