
#ifndef DELETEPROCESS_H
#define DELETEPROCESS_H

#include "cprocess.h"
#include <QString>


class DeleteProcess : public CProcess
{
private:
    QString path;
    QString parentPath;
    QString repository;
    QString branch;
    QString file;
    void deleteDir();
    void deleteFile();
    void getFilesName();
    QString getDirType(QString dir);

public:
    DeleteProcess(QList<QByteArray> tokens);
    void run()override;
    void read_from_socket();
    void delete_name_from_repository();
    void delete_name_from_branch();
};

#endif // DELETEPROCESS_H
