

#include "sendcommitfileprocess.h"
#include "cprotocol.h"
#include "logger.h"

#include <QFile>
#include <QTextStream>

SendCommitFileProcess::SendCommitFileProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void SendCommitFileProcess::run()
{
    read_from_socket();
    Logger::getInstance()->write(this->username+" a initiat procesul de SendCommitFile");
    QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::BranchList).toUtf8();
    block_to_send=block_to_send+protocol+" ";
    getFileContent();
    Logger::getInstance()->write("Procesul de SendCommitFile initiat de "+ this->username+" a fost executat");

}

void SendCommitFileProcess::read_from_socket()
{
    tokens.removeAt(0);
    this->repositoryName=this->tokens[0];
    this->tokens.removeAt(0);
    this->branchName=this->tokens[0];
    this->tokens.removeAt(0);
    this->version=tokens[0];
    this->tokens.removeAt(0);

}

void SendCommitFileProcess::getFileContent()
{
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName+"/"+this->version;
    QFile file(path);
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QTextStream text(&file);
        QString line=text.readLine(); //citesc linia de tag, ca sa nu o trimit si pe aia
        while(!text.atEnd()){
            line=text.readLine();
            this->block_to_send=this->block_to_send+line.toUtf8();
            this->block_to_send=this->block_to_send+"\n";
        }
    }
}

