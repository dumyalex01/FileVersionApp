
#ifndef IPROCESS_H
#define IPROCESS_H

#include <QString>
#include <QByteArray>

class IProcess
{
public:
    virtual void run()=0;
   //virtual void setUser(QString user)=0;
    virtual void setPassword(QString password)=0;
  //  virtual void setData(QDataStream* data)=0;
    virtual QByteArray sendDatatoSocket()=0;
};

#endif // IPROCESS_H
