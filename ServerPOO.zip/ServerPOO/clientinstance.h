
#ifndef CLIENTINSTANCE_H
#define CLIENTINSTANCE_H


#include <QObject>
#include <QTcpSocket>
#include <QThreadPool>


class ClientInstance : public QObject
{
    Q_OBJECT
private:
    QTcpSocket* socket;
    int ClientID;
    int socketDescriptor;
public:
    explicit ClientInstance(QObject *parent = nullptr);
    void setSocket(int Descriptor);
    void setClientID(int id){this->ClientID=id;};
    void write(QByteArray block_to_send);

public slots:
    void disconnected();
    void connected();
    void readyRead();
signals:
    void clientDisconnected();

};

#endif // CLIENTINSTANCE_H
