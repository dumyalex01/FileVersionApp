
#ifndef SENDREPOSITORYPROCESS_H
#define SENDREPOSITORYPROCESS_H

#include "cprocess.h"

#include <QList>
#include <QByteArray>



class SendRepositoryProcess : public CProcess
{

public:
    SendRepositoryProcess(QList<QByteArray> tokens);
    void run()override;
    void read_from_socket();
    void getRepList();

};

#endif // SENDREPOSITORYPROCESS_H
