
#ifndef SENDVERSIONSPROCESS_H
#define SENDVERSIONSPROCESS_H

#include "cprocess.h"

#include <QList>
#include <QByteArray>
#include <QString>

class SendVersionsProcess : public CProcess
{
    QString repositoryName;
    QString branchName;
    void getRepBranCH(QString path);
public:
    SendVersionsProcess(QList<QByteArray> tokens);
    void read_from_socket();
    void getVersionList();
    void run()override;
};

#endif // SENDVERSIONSPROCESS_H
