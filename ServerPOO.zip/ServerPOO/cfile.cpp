
#include "cfile.h"
#include "server.h"

#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QStringList>

CFile::CFile()
{

}

CFile::CFile(QString repository, QString branch)
{
    this->repositoryName=repository;
    this->branchName=branch;
    QDir file_directory;
    QString path="C:/Users/Alex/Desktop/test";
    path=path+"/"+this->repositoryName;
    if(!file_directory.exists(path)){ //verificam daca exista director cu acest nume
        if(file_directory.mkdir(path)) {//Daca nu exista il creez;

            //Fac fisierul de acces
            QString path_file="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->repositoryName+"_access.txt";
            QFile access_file(path_file);
            if(access_file.open(QIODevice::ReadWrite | QIODevice::Text)){
                QTextStream ids(&access_file);
                QStringList admins=Server::getInstance()->getAdmins();
                for(int i=0;i<admins.size();i++)
                    ids<<admins[i]<<"\n";
                access_file.close();
            }else{
                qDebug()<<"Eroare la deschiderea fisierului de acces";
            }

            //fac branch<=>trunk
            path_file="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName;
            QDir trunk;
            if(!trunk.exists(path_file)){ //verific daca exista trunk, daca nu il creez
                if(trunk.mkdir(path_file)){
                    //creez fisierul cu prima versiune;
                    path_file=path_file+"/"+this->repositoryName+"_"+this->branchName+"_1.txt";  //modificat
                    QFile content1(path_file);
                    if(content1.open(QIODevice::ReadWrite|QIODevice::Text)){
                        content1.close();
                    }else {
                        qDebug()<<"Eroare la deschiderea primei versiune";
                    }
                }

            }
            //fac fisierul cu lista de branch uri
            path_file="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+"branch_list.txt";
            QFile branch_list(path_file);
            if(branch_list.open(QIODevice::ReadWrite|QIODevice::Text)){
                QTextStream text(&branch_list);
                text<<"trunk";
                branch_list.close();
            }else {
                qDebug()<<"Eroare la deschiderea fisierului cu lista de branch uri";
            }

            //Adaug in fisierul din FileDirectory numele noului repository creat
            path_file="C:/Users/Alex/Desktop/test/repository_list.txt";
            QFile rep_list(path_file);
            if(rep_list.open(QIODevice::Append|QIODevice::Text)){
                QTextStream text(&rep_list);
                text<<this->repositoryName+"\n";
                rep_list.close();
            }

        }
    }
}



