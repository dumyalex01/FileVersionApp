
#ifndef IFILE_H
#define IFILE_H

#include <QString>
#include <vector>
using namespace std;


class IFile
{
public:
    virtual QString getFilename()=0;
  //  virtual void modify(int type)=0;
  //  virtual vector<int> getAccessPersons()=0;
    //virtual void addUsersID(int id)=0;
    //virtual int getVersionNumber()=0;
};

#endif // IFILE_H
