#ifndef PROPERTIES_H
#define PROPERTIES_H

#include "cprocess.h"


#include <vector>
#include <QSql>
using namespace std;
class Properties : public CProcess
{private:
    vector <pair<QString,QString>> NumeID;
    QString id;
    QString transformToName(QString id);
public:
    Properties(QByteArrayList tokens);
    void run() override;
    void read_from_socket();
};

#endif // PROPERTIES_H
