
#include "cprocess.h"

CProcess::CProcess(QList<QByteArray> tokens)
{
    this->tokens=tokens;
}

