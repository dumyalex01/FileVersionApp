#ifndef VIEWPROCESS_H
#define VIEWPROCESS_H

#include "cprocess.h"

class ViewProcess : public CProcess
{
    QString filename;
public:
    ViewProcess(QByteArrayList tokens);
    void run() override;
    void read_from_socket();
};

#endif // VIEWPROCESS_H
