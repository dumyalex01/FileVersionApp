
#include "branch.h"
#include "textfile.h"
#include "server.h"

#include <QTextStream>
#include <QStringList>
#include <QDir>
#include <QFile>

Branch::Branch(QString repository, QString branch="trunk"):CFile(repository,branch)
{
    //deschid directorul branch
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName;
    QDir branch_dir(path);
    if(branch_dir.exists(path)){

        QFileInfoList list = branch_dir.entryInfoList();
        //QFileInfo file;
        for (int i=0;i<list.size();i++) {
            if (list[i].suffix() == "txt") {
                this->versions.push_back(list[i].fileName());
            }

        }
        this->versionsNumber=this->versions.size();
    }else{

        QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName;
        QDir newBranch(path);
            if(newBranch.mkdir(path)){
                //Am creat un nou Branch
            }

            //Adaug noul branch la fisierul cu lista de branch-rui;

            path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/branch_list.txt";
            QFile file(path);
            if (file.open(QIODevice::Append | QIODevice::Text)) {
                QTextStream stream(&file);
                stream<<"\n";
                stream << this->branchName;
                file.close();
            }

    }
    QStringList list;

}

QStringList Branch::getContent(QString filename)
{
    QStringList lines;
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName+"/"+filename;
    QFile file(path);
        if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
            QTextStream text(&file);
            QString line;
            //QString line=text.readLine(); //citesc linia pt tag
            while(!text.atEnd()){
                line=text.readLine();
                lines.append(line);
            }
        return lines;
    }

}

QString Branch::getFirstFile()
{
    QStringList lines;
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName;
    QDir branch;
    if(branch.exists(path)){
            QStringList list=branch.entryList();
            for(int i=0;i<list.length();i++){
                if(list[i].contains(this->repositoryName)){
                return list[i];
                }
            }
    }
}


