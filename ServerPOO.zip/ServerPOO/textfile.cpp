
#include "textfile.h"
#include "branch.h"

#include <QDir>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QDateTime>


TextFile::TextFile(QString filename, QString fileParent):CFile(filename,fileParent)
{
    vector<QString> branchesName;
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/branch_list.txt";
    QFile branch_list(path);
    if(branch_list.open(QIODevice::ReadOnly|QIODevice::Text)){

        //populez vectorul pentru branch-uri
        QTextStream read(&branch_list);
        while(!read.atEnd()){
            QString line=read.readLine();
            this->branches++;
        }
    }


}

vector<QString> TextFile::getBranchesName(QString branch)
{
    vector<QString> branchesName;
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/branch_list.txt";
    QFile branch_list(path);
    if(branch_list.open(QIODevice::ReadOnly|QIODevice::Text)){

        //populez vectorul pentru branch-uri
        QTextStream read(&branch_list);
        while(!read.atEnd()){
            QString line=read.readLine();
             branchesName.push_back(line);
        }
    }
    return branchesName;
}

bool TextFile::check_access(int ClientID)
{
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->repositoryName+"_access.txt";
    QFile access_list(path);
    if(access_list.open(QIODevice::ReadOnly|QIODevice::Text)){

        QTextStream in(&access_list);
        while (!in.atEnd()) {
             QString line = in.readLine();
             if(ClientID==line.toInt())
                 return true;
        }
    }
    return false;
}

void TextFile::addClientID(int ClientID)
{
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->repositoryName+"_access.txt";
    QFile file(path);
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream stream(&file);
        stream<<"\n";
        stream << ClientID;
        file.close();
    }
}

void TextFile::addFile(QList<QByteArray> tokens, QString username)
{

    Branch *branch=new Branch(this->repositoryName, this->branchName);
    int version=branch->getVersionNumber();
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName+"/"+this->repositoryName+"_"+this->branchName+"_"+QString::number(++version)+".txt";
    QFile newFile(path);
    if(newFile.open(QIODevice::WriteOnly | QIODevice::Text)){
        QTextStream out(&newFile);
        QDateTime currentDateTime = QDateTime::currentDateTime();
        QString currentDateTimeString = currentDateTime.toString(Qt::ISODate);
        currentDateTimeString.append("\n");
        out<<"This file was changed by "<<username<< " at->"+currentDateTimeString;
        for(auto it=tokens.begin();it!=tokens.end();it++){
             QString line=QString::fromUtf8(*it);
             line.append("\n");
             out<<line;
        }
        newFile.close();
    }else {
        qDebug() << "Error opening file: " << newFile.errorString();
    }

}

void TextFile::addFile(QStringList newFile, QString username)
{
    Branch *branch=new Branch(this->repositoryName, this->branchName);
    int version=branch->getVersionNumber();
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/"+this->branchName+"/"+this->repositoryName+"_"+this->branchName+"_"+QString::number(version)+".txt";
    QFile file(path);
    if(file.open(QIODevice::WriteOnly|QIODevice::Text)){
        QTextStream out(&file);
        QDateTime currentDateTime = QDateTime::currentDateTime();
        QString currentDateTimeString = currentDateTime.toString(Qt::ISODate);
        out<<"TAG:"+username+" merged this file"+"->"+currentDateTimeString;
        for(int i=0;i<newFile.size();i++){

             out<<newFile[i];
        }
        file.close();
    }
}
