
#include "sendbranchprocess.h"
#include "server.h"
#include "cprotocol.h"
#include "logger.h"

#include <QFile>

SendBranchProcess::SendBranchProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void SendBranchProcess::read_from_socket()
{
    this->tokens.removeAt(0);
    this->repositoryName=this->tokens[0];
    //this->username=tokens[0];
    //this->clientID=Server::getInstance()->giveID(this->username);
}

void SendBranchProcess::run()
{
    read_from_socket();
   // Logger::getInstance()->write(this->username+"a initiat procesul de SendBranchList");
    //QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::BranchList).toUtf8();
    //block_to_send=block_to_send+protocol+" ";
    getBranchList();
    //Logger::getInstance()->write("Procesul de SendBranchList intiat de "+ this->username+" a fost executat");

}

void SendBranchProcess::getBranchList()
{
    int nr=0;
    QString buff;
    QString path="C:/Users/Alex/Desktop/test/"+this->repositoryName+"/branch_list.txt";
    QFile file(path);
    //Deschid lista de fisiere
    if(file.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream text(&file);
        while(!text.atEnd()){
            QString line = text.readLine();
               // QByteArray buff;
               // buff=line.toUtf8();
                //this->block_to_send=this->block_to_send+buff+" ";
            buff=buff+line+" ";
            nr++;

        }
    }
    QString number=QString::number(nr);
    this->block_to_send=this->block_to_send+number.toUtf8()+" "+buff.toUtf8();
}



