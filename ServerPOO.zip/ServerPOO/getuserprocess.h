#ifndef GETUSERPROCESS_H
#define GETUSERPROCESS_H
#include <vector>
#include "cprocess.h"
using namespace std;
class GetUserProcess : public CProcess
{private:
    QString name;
    vector<pair<QString,QString>> UsersID;
    QString getID();
public:
    void read_from_socket();
    GetUserProcess(QByteArrayList tokens);
    void run() override;

};

#endif // GETUSERPROCESS_H
