
#ifndef HELPPROCESS_H
#define HELPPROCESS_H

#include "cprocess.h"



class HelpProcess : public CProcess
{
public:
    HelpProcess(QByteArrayList tokens);
    void run()override;
};

#endif // HELPPROCESS_H
