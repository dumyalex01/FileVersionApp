
#include "iprotocol.h"

IProtocol::IProtocol()
{

}

