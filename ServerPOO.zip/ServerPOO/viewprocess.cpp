
#include "viewprocess.h"

#include <QDebug>
#include <fstream>
using namespace std;


ViewProcess::ViewProcess(QByteArrayList tokens):CProcess(tokens)
{

}

void ViewProcess::read_from_socket()
{
    //Cred ca asa e
    this->tokens.removeFirst();
    this->filename=this->tokens[0];
    QString a=this->filename;
    qDebug()<<a;
    //qDebug()<<filename;
}

void ViewProcess::run()
{   read_from_socket();
    const char* path=this->filename.toUtf8().constData();
    ifstream file(path);
    char buffer[250];
    QString message;
    while(file.getline(buffer,250))
    {
        message.append(buffer);
        message.append("\n");
    }
    qDebug()<<message;

    this->block_to_send=this->block_to_send+message.toUtf8();
    sendDatatoSocket();

}


