
#include "commitprocess.h"
#include "server.h"
#include "branch.h"
#include "textfile.h"
#include "cprotocol.h"
#include "logger.h"

#include <QFile>
#include <QDataStream>
#include <QTextStream>
#include <QTcpSocket>
#include <QStringList>


void CommitProcess::getFiles(QString path)
{
    QStringList files=path.split("/");
    this->username=files[files.size()-1];
    this->version=files[files.size()-2];
    this->branchName=files[files.size()-3];
    this->repositoryName=files[files.size()-4];


}

CommitProcess::CommitProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void CommitProcess::run()
{
   read_from_socket();
  // Logger::getInstance()->write(this->username+" a initial procesul de Commit");
   if(check_for_changes()){
   addNewVersion();
   QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::CommitExecuted).toUtf8();
   //Logger::getInstance()->write("Procesul de Commit initial de "+this->username+" a fost executat");
   block_to_send=block_to_send+protocol;
   }else{
   QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::CommitFailed).toUtf8();
   block_to_send=block_to_send+protocol;
   //Logger::getInstance()->write("Procesul de Commit initial de "+this->username+" nu a fost executat");
   }

}

void CommitProcess::read_from_socket()
{

    this->tokens.removeAt(0);
    //this->username=tokens[0];
    QString path=this->tokens[0];
    this->tokens.removeAt(0);
    QString A=this->tokens[0];
    this->content=A.toUtf8().split('\n');
    //this->version=this->tokens[0];  //le trimite cu .txt????
    getFiles(path);
}

void CommitProcess::addNewVersion()
{
    TextFile* rep=new TextFile(this->repositoryName,this->branchName);
    rep->addFile(this->content,this->username);
}

bool CommitProcess::check_for_changes()
{
    Branch* branch=new Branch(this->repositoryName,this->branchName);
    QStringList originalFile=branch->getContent(this->version);
    if(originalFile.size()!=this->tokens.size())
        return true;
    for(int i=0;i<originalFile.size() && this->tokens.size();i++){
        if(originalFile[i]!=this->tokens[i])
            return true;
    }
    return false;
}



