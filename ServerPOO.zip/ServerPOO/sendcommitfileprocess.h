
#ifndef SENDCOMMITFILEPROCESS_H
#define SENDCOMMITFILEPROCESS_H

#include "cprocess.h"

#include <QList>
#include <QByteArray>

class SendCommitFileProcess : public CProcess
{
private:
    QString repositoryName;
    QString branchName;
    QString version;
public:
    SendCommitFileProcess(QList<QByteArray> tokens);
    void run()override;
    void read_from_socket();
    void getFileContent();
};

#endif // SENDCOMMITFILEPROCESS_H
