
#include "authentificationprocess.h"
#include "logger.h"
#include "cprotocol.h"

#include <QSqlDatabase>
#include <QSqlQuery>

AuthentificationProcess::AuthentificationProcess(QList<QByteArray> tokens):CProcess(tokens)
{

}

void AuthentificationProcess::run()
{
    read_from_socket();
    addInDatabase();

}

void AuthentificationProcess::read_from_socket()
{
    this->tokens.removeFirst();
    this->username=this->tokens[0];
    this->tokens.removeFirst();
    this->password=this->tokens[0];
    this->tokens.removeFirst();
}

bool AuthentificationProcess::addInDatabase()
{
    QSqlQuery query;
    query.prepare("SELECT * FROM Conturi WHERE utilizator = :utilizator");
    query.bindValue(":utilizator",this->username);
    query.exec();

    if(query.next()){
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::FoundRegistration).toUtf8();
       block_to_send=block_to_send+protocol;
       return false;
    }
    else
    {
       //Nu stiu cum il ai tu la tip
        query.prepare("INSERT INTO Conturi(utilizator,parola,rol) VALUES(:username,:password,:type)");
        query.bindValue(":username",this->username);
        query.bindValue(":password",this->password);
        query.bindValue(":type","Obisnuit");

        if(!query.exec()){
            QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::InvalidCredentials).toUtf8();
            block_to_send=block_to_send+protocol;
        return false;
        }
        else{
        query.prepare("SELECT * FROM Conturi WHERE utilizator = :utilizator and parola = :parola");
        query.bindValue(":utilizator",this->username);
        query.bindValue(":parola",this->password);

        query.exec();
        if(query.next()){
            this->clientId=query.value(0).toString();
            this->type=query.value(3).toString();
        }
        QByteArray protocol=CProtocol::getInstance()->getProtocoltoSend(ProtocolsToSend::ValidCredentials).toUtf8();
        block_to_send=block_to_send+protocol+" "+this->clientId.toUtf8()+" "+this->type.toUtf8();
            return true;
        }
    }
}

