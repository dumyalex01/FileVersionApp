
#ifndef LOGINPROCESS_H
#define LOGINPROCESS_H

#include "cprocess.h"



class loginProcess : public CProcess
{
    QString password;
    QString clinetId;
    QString type;
    void read_from_socket();
public:
    loginProcess(QList<QByteArray> tokens);
    void run()override;
    bool checkforCredentials();

};

#endif // LOGINPROCESS_H
