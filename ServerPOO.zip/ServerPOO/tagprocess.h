#ifndef TAGPROCESS_H
#define TAGPROCESS_H

#include "cprocess.h"

class TagProcess : public CProcess
{
private:
    QString repository;
    QString branch;
    QString version;
    QString tagName;
public:
    TagProcess(QList<QByteArray> tokens);
    void run() override;
    void copyDirectoryRecursively();
    void read_from_socket();
};

#endif // TAGPROCESS_H
