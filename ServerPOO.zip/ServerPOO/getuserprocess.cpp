#include "getuserprocess.h"
#include "textfile.h"
#include "server.h"

#include <QFile>
#include <QDebug>

QString GetUserProcess::getID()
{
    bool found=0;
    for(int i=0;i<this->UsersID.size();i++)
        if(this->UsersID[i].second==this->name)
            return this->UsersID[i].first;
    if(found==0)
        return "-1";
}

void GetUserProcess::read_from_socket()
{
    this->tokens.removeFirst();
    this->name=this->tokens[0];

    this->UsersID=Server::getInstance()->getNameID();
}

GetUserProcess::GetUserProcess(QByteArrayList tokens):CProcess(tokens)
{
    this->name=name;
    this->UsersID=UsersID;
}

void  GetUserProcess::run()
{   read_from_socket();
    for(int i=0;i<UsersID.size();i++)
        qDebug()<<UsersID[i].first<<"\n";
    QString id= this->getID();
    QString finalMessage;
    if(id!="-1")
    {
        QString path="C:/Users/Alex/Desktop/test/repository_list.txt";
        QFile f(path);
        if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qDebug()<<"eroare";
        }
        else
        {   int contorLiniute=10;
            finalMessage=" ";
            while(!f.atEnd())
            {
                QByteArray repoName=f.readLine();
                QStringList aux=QString::fromUtf8(repoName).split("\n");
                TextFile repo(aux.at(0),"trunck");
                if(repo.check_access(id.toInt()))
                {   for(int i=0;i<contorLiniute;i++)
                        finalMessage+="-";
                    contorLiniute=contorLiniute+3;
                    finalMessage+=QString::fromUtf8(repoName);
                    finalMessage+=" ";
                }


            }
            qDebug()<<finalMessage;
            this->block_to_send=this->block_to_send+ finalMessage.toUtf8();
            sendDatatoSocket();
        }

    }
    else {
        this->block_to_send=this->block_to_send+"EROARE";
        sendDatatoSocket();}



}
