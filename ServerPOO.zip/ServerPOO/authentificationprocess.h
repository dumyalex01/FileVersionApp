
#ifndef AUTHENTIFICATIONPROCESS_H
#define AUTHENTIFICATIONPROCESS_H

#include "cprocess.h"



class AuthentificationProcess : public CProcess
{
    QString username;
    QString password;
    QString type;
    QString clientId;
public:
    AuthentificationProcess(QList<QByteArray> tokens);
    void run()override;
    void read_from_socket();
    bool addInDatabase();
};

#endif // AUTHENTIFICATIONPROCESS_H
