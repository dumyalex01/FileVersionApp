#ifndef PAGINASELECTIEFISIERE_H
#define PAGINASELECTIEFISIERE_H
#include <iutilizator.h>
#include <QVBoxLayout>
#include <QWidget>
#include <QCheckBox>
#include <QLabel>
#include <protocols.h>
#include <QComboBox>
#include "logger.h"
namespace Ui {
class PaginaSelectieFisiere;
}

class PaginaSelectieFisiere : public QWidget
{
    Q_OBJECT


public:
    explicit PaginaSelectieFisiere(IUtilizator*A,QString codActiune,QWidget *parent = nullptr);
    ~PaginaSelectieFisiere();


private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

private:
    IUtilizator*A;
    QString codActiune;//reprezinta o variabila prin care la finalul procesului de selectie se alege actiunea(view,delete,etc)
    void sendMessageToServer(QByteArray& text,QString message);
    void GetBranchMessage(QString Repo,QByteArray&text);
    void selectFile(QString Branch,QString Repo);
    void getComboRepository();
    void resetMessage(QString& message,QString toStart);
    void getComboBranches(QString Repo);
    void getComboFiles(QString Branch);
    void designComboBox(QComboBox*& box);
    void setForGiveAdminProcess();
    Protocols protocol;
    QLabel* eti;
    QString message;
    QString repo;
    QString branch;
    QString branch2;
    QString version2;
    QComboBox* comboBranch2;  //pt merge
    QComboBox* comboFiles2;
    QString version;
    QComboBox*combo;
    QComboBox* comboBranch;
    QComboBox* comboFiles;
    Ui::PaginaSelectieFisiere *ui;
};

#endif // PAGINASELECTIEFISIERE_H
