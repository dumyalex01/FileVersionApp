#ifndef EDITORTEXT_H
#define EDITORTEXT_H

#include <QWidget>
#include "iutilizator.h"
namespace Ui {
class EditorText;
}

class EditorText : public QWidget
{
    Q_OBJECT

public:
    explicit EditorText(bool readOnly,QByteArray a,QString path,IUtilizator*A,QWidget *parent = nullptr);
    ~EditorText();

private slots:
    void on_pushButton_clicked();

private:
    IUtilizator* A;
    QString pathForCommit;
    Ui::EditorText *ui;
};

#endif // EDITORTEXT_H
