#ifndef IUTILIZATOR_H
#define IUTILIZATOR_H

#include <QObject>
#include <QString>
class IUtilizator
{
public:
    virtual QString getUsername()=0;
    virtual void giveAdmin(QString numeUtilizator)=0;
    virtual int getID()=0;

};

#endif // IUTILIZATOR_H
