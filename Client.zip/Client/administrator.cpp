#include "administrator.h"


void Administrator::giveAdmin(QString numeUtilizator)
{

}

Administrator::Administrator(QString id, QString userName)
{
    this->id=id.toInt();
    this->userName=userName;
}
