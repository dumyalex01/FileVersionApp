#ifndef UTILIZATORSIMPLU_H
#define UTILIZATORSIMPLU_H

#include "cutilizator.h"
#include <QObject>

class UtilizatorSimplu : public CUtilizator
{
public:
    UtilizatorSimplu(QString id,QString numeUtilizator);
    void giveAdmin(QString numeUtilizator);

};

#endif // UTILIZATORSIMPLU_H
