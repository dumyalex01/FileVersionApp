#ifndef CEXCEPTII_H
#define CEXCEPTII_H


class CExceptii
{
public:
    CExceptii();
};

#endif // CEXCEPTII_H
