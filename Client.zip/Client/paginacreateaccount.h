#ifndef PAGINACREATEACCOUNT_H
#define PAGINACREATEACCOUNT_H
#include "protocols.h"
#include <QWidget>
#include "logger.h"
namespace Ui {
class paginaCreateAccount;
}

class paginaCreateAccount : public QWidget
{
    Q_OBJECT

public:
    explicit paginaCreateAccount(QWidget *parent = nullptr);
    ~paginaCreateAccount();

private slots:
    void on_pushButton_clicked();

private:
    Protocols protocol;
    Ui::paginaCreateAccount *ui;
};

#endif // PAGINACREATEACCOUNT_H
