#ifndef PAGINAOPTIUNIADMIN_H
#define PAGINAOPTIUNIADMIN_H

#include <QWidget>

namespace Ui {
class PaginaOptiuniAdmin;
}

class PaginaOptiuniAdmin : public QWidget
{
    Q_OBJECT

public:
    explicit PaginaOptiuniAdmin(QWidget *parent = nullptr);
    ~PaginaOptiuniAdmin();

private:
    Ui::PaginaOptiuniAdmin *ui;
};

#endif // PAGINAOPTIUNIADMIN_H
