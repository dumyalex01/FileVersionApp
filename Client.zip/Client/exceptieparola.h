#ifndef EXCEPTIEPAROLA_H
#define EXCEPTIEPAROLA_H
#include <QMessageBox>
#include "iexceptii.h"

class ExceptieParola : public IExceptii
{
public:
    ExceptieParola();
    void throwMessage(QWidget* parent);
};

#endif // EXCEPTIEPAROLA_H
