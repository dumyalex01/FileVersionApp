#include "datatypes.h"

DataTypes::DataTypes()
{

}
