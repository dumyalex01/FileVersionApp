#include "paginaselectiefisiere.h"
#include "ui_paginaselectiefisiere.h"
#include <QLabel>
#include "paginaoptiuni.h"
#include <QTcpSocket>
#include <QVBoxLayout>
#include <QButtonGroup>
#include <QCheckBox>
#include "paginaoptiuni.h"
#include <QPushButton>
#include <QMessageBox>
#include <QComboBox>
#include <editortext.h>
PaginaSelectieFisiere::PaginaSelectieFisiere(IUtilizator*A,QString codActiune,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaginaSelectieFisiere)
{
    this->A=A;
    this->codActiune=codActiune;
    ui->setupUi(this);
    this->designComboBox(combo);
    this->ui->frame->hide();
    this->ui->pushButton_2->hide();
    this->ui->pushButton_3->hide();
    this->ui->lineEdit_2->setReadOnly(true);
    this->ui->lineEdit_2->hide();
    this->ui->lineEdit->hide();
    this->ui->pushButton_4->hide();
    if(this->codActiune=="5")
    {   this->ui->pushButton_6->setText("DELETE");
        this->ui->pushButton_6->show();

    }
    else this->ui->pushButton_6->hide();
    if(this->codActiune=="6")
        this->setForGiveAdminProcess();
      else this->getComboRepository();

}

PaginaSelectieFisiere::~PaginaSelectieFisiere()
{
    delete ui;
}

void PaginaSelectieFisiere::sendMessageToServer(QByteArray &text, QString message)
{
    QTcpSocket socket;
        socket.connectToHost("127.0.0.1", 1234);
        if (socket.waitForConnected()) {
            socket.write(message.toUtf8());
            socket.flush();
            if(socket.waitForReadyRead(30000))
            {
                text = socket.readAll();
            }
            socket.disconnectFromHost();
        } else {
            qDebug() << "Nu s-a putut realiza conexiunea la server!";
        }
}

void PaginaSelectieFisiere::getComboRepository()
{
    QByteArray text;
    this->message=protocol.SendRepoCODE;
    message.append(QString::number(A->getID()));
    this->sendMessageToServer(text,message);
    QString t=QString::fromUtf8(text);
    QStringList list = t.split(' ');
    int numar=list.at(0).toInt();
    this->eti=new QLabel(this);
    this-> eti->move(20,55);
    this-> eti->setText("Selecteaza repository-ul:");
    this->combo->move(170,52);
    for(int i=0;i<numar;i++)
        this->combo->addItem(list.at(i+1));
    this->show();
    if(numar==0)
        QMessageBox::information(this,"Problema","Nu ai acces la niciun repository!");



}
void PaginaSelectieFisiere::getComboBranches(QString Repo)
{   delete eti;
    this->combo=nullptr;
    QByteArray text;
    this->message=protocol.SendBranchCODE;
    message.append(Repo);
    this->sendMessageToServer(text,message);
    QString t=QString::fromUtf8(text);
    QStringList list=t.split(' ');
    int numar=list.at(0).toInt();
    this-> eti=new QLabel(this);
    this-> eti->move(20,55);
    this->eti->setText("Selecteaza branch-ul:");
    this-> eti->show();
    this->designComboBox(comboBranch);
    this->comboBranch->move(170,52);
    this->comboBranch->show();
    for(int i=0;i<numar;i++)

    {
        this->comboBranch->addItem(list.at(i+1));
    }
    if(this->codActiune=="8")
    {
        this->designComboBox(comboBranch2);
        this->comboBranch2->move(170,150);
        this->comboBranch2->show();
        for(int i=0;i<numar;i++)
            this->comboBranch2->addItem(list.at(i+1));
    }

}

void PaginaSelectieFisiere::getComboFiles(QString path)
{
    this->comboBranch=nullptr;
    QByteArray text;
    this->message=protocol.SendVersionCODE;
    message.append(path);
    this->sendMessageToServer(text,message);
    QString t=QString::fromUtf8(text);
    QStringList list=t.split(' ');
    int numar= list.at(0).toInt();
    this->eti=new QLabel(this);
    this->eti->move(20,55);
    this->eti->setText("Selecteaza fisierul:");
    this->eti->show();
    this->designComboBox(this->comboFiles);
    this->comboFiles->move(170,52);
    this->comboFiles->show();
    for(int i=0;i<numar;i++)
        this->comboFiles->addItem(list.at(i+1));
    if(this->codActiune=="8")
    {
        this->designComboBox(comboFiles2);
        this->comboFiles2->move(170,150);
        this->comboFiles2->show();
        for(int i=0;i<numar;i++)
            this->comboFiles2->addItem(list.at(i+1));
    }
}

void PaginaSelectieFisiere::designComboBox(QComboBox *&box)
{
    box=new QComboBox(this);
    box->setFixedWidth(200);
    box->setStyleSheet("QComboBox { background-color: #f2f2f2; border: 1px solid #f2f2f2; }"
                                "QComboBox::drop-down { border: none; }"
                       "QComboBox::down-arrow { image: url(:/images/arrow_down.png); }");
}

void PaginaSelectieFisiere::setForGiveAdminProcess()
{
    this->ui->pushButton->hide();
    this->ui->label->hide();
    this->ui->label_2->hide();
    this->ui->pushButton_2->hide();
    this->combo->hide();
    this->ui->frame->show();
    this->ui->lineEdit->show();
    this->ui->lineEdit_2->show();
    this->ui->pushButton_6->setText("GiveAdmin");
    this->ui->pushButton_6->show();
}



void PaginaSelectieFisiere::on_pushButton_clicked()//trece la comboBranch
{
    QString str="C:/Users/Alex/Desktop/test/";

    str+=this->combo->currentText();
    this->repo=this->combo->currentText();
    this->ui->pushButton->hide();
    this->ui->label->setText(str);
    if(this->codActiune=="17")
    {   this->ui->frame->show();
        delete this->combo;
        this->eti->hide();
        this->message=protocol.GiveAccessCODE; // pentru giveAccess
        this->message+=this->repo;
        this->message+=" ";
        this->ui->label_2->hide();
        this->ui->label->hide();
        this->ui->lineEdit->show();
        this->ui->lineEdit_2->show();
        this->ui->pushButton_4->show();
        this->ui->pushButton->hide();
        this->ui->pushButton_2->hide();
        this->ui->pushButton_3->hide();

    }
    else if(this->codActiune=="3") //branch
    {   delete this->combo;
        this->getComboBranches(this->repo);
        this->ui->pushButton_2->show();

    }
    else if(this->codActiune=="5")
    {
        delete this->combo;
        this->getComboBranches(this->repo);
        this->ui->pushButton_2->show();
    }
    else
    {delete this->combo;
        this->getComboBranches(this->repo);
        this->ui->pushButton_2->show();
    }
}


void PaginaSelectieFisiere::on_pushButton_2_clicked() // trece la fisiere
{       QString str=this->ui->label->text();
        str+="/";
        str+=this->comboBranch->currentText();
        this->branch=this->comboBranch->currentText();
    if(this->codActiune=="8")//merge
    {
        this->branch2=this->comboBranch2->currentText();
        delete this->comboBranch2;
        delete eti;
        this->getComboFiles(str);

    }
    else
    if(this->codActiune=="20") //daca  este tag se opreste la branch uri si trece la selectarea unui nume,dupa care se trimite mesaj la sv
    {
        this->ui->frame->show();
        this->ui->lineEdit->show();
        this->ui->lineEdit_2->show();
        this->ui->lineEdit_2->setText("Dati numele tag:");
        this->ui->pushButton_3->setText("Tag");
        this->ui->pushButton_3->show();
        this->ui->pushButton_2->hide();
        delete this->comboBranch;
        delete eti;

    }
else
    {
    delete eti;
    delete this->comboBranch;
    this->ui->label->setText(str);
    this->getComboFiles(str);
    this->ui->pushButton_3->show();
    this->ui->pushButton_2->hide();
    }



}


void PaginaSelectieFisiere::on_pushButton_3_clicked() // buton trimitere comenzi(Delete,View,Commit,etc..) READY
{
    if(this->codActiune=="20")
    {
        QString message="20 ";
        QByteArray text;
        message.append(this->repo);
        message.append(" ");
        message.append(this->branch);
        message.append(" ");
        message.append(this->ui->lineEdit->text());
        this->sendMessageToServer(text,message);
        if(text.contains("DA"))
        {   Logger::getInstance()->write("Tag creat cu succes de " + this->A->getUsername());
            QMessageBox::information(this,"Succes!","S-a creat cu succes noul tag!");
        }
        else QMessageBox::information(this,"Problema!","Problema la creere tag!");
    }
    else{
    QString path=this->ui->label->text();
    QByteArray text;
    path+="/";
    path+=this->comboFiles->currentText();
    this->ui->label->setText(path);
    this->version=this->comboFiles->currentText();
    if(this->codActiune=="12") //View
    {
        this->sendMessageToServer(text,protocol.ViewCODE+path);
        if(text=="")
            QMessageBox::information(this,"Eroare!","Fisierul este gol!");
        else
        {   Logger::getInstance()->write("View realizat cu succes!");
        EditorText* edit=new EditorText(1,text,"",this->A);
        edit->setWindowTitle(this->comboFiles->currentText());
        edit->show();
        this->hide();
        }
    }
    if(this->codActiune=="3") //branch
    {   delete this->comboFiles;
        delete this->eti;
        this->ui->frame->show();
        this->ui->lineEdit_2->setText("Noul branch:");
        this->ui->lineEdit_2->show();
        this->ui->lineEdit->show();
        this->ui->pushButton_6->setText("Branch");
        this->ui->pushButton_6->show();
    }
    if(this->codActiune=="16") //commit
    {
        QByteArray text;
        QString message;
        message.append("16 ");
        message.append(this->repo);
        message.append(" ");
        message.append(this->branch);
        message.append(" ");
        message.append(this->version);
        this->sendMessageToServer(text,message);
        EditorText* edit=new EditorText(false,text,path,this->A);
        edit->show();
    }
    if(this->codActiune=="8") //merge
    {   QString message="8 ";
        QByteArray text;
        this->version2=this->comboFiles2->currentText();
        this->version=this->comboFiles->currentText();
        message.append(this->repo);
        message.append(" ");
        message.append(this->branch);
        message.append(" ");
        message.append(this->version);
        message.append(" ");
        message.append(this->branch2);
        message.append(" ");
        message.append(this->version2);
        delete this->comboFiles2;
        delete this->comboFiles;
        this->sendMessageToServer(text,message);
        if(text=="NU")
        {   Logger::getInstance()->write("Merge reusit");
            QMessageBox::information(this,"Merge reusit!","Merge reusit!");
        }
        else
        {
            QMessageBox::information(this,"Merge nereusit!","Merge nereusit!");
            Logger::getInstance()->write("Merge nereusit!");
        }
    }

}



}


void PaginaSelectieFisiere::on_pushButton_4_clicked() //GiveAcces
{   if(this->codActiune=="17")
    {
    QString user=this->ui->lineEdit->text();
    QByteArray text;
    QString copyForNoRepeat=this->message;  //atunci cand incerc sa trimit de mai multe ori un username sa nu se concateneze sirul
    this->message+=user;
    this->sendMessageToServer(text,this->message);
    if(text=="-1")
    {  Logger::getInstance()->write("GiveAccess nereusit!");
        QMessageBox::information(this,"Actiune nereusita!","User-ul nu exista!");
    }
    if(text=="1")
    {   Logger::getInstance()->write("GiveAccess reusit!");
        QMessageBox::information(this,"Actiune reusita!","User-ul a primit acces!");
    }
    if(text=="-2")
    {   Logger::getInstance()->write("GiveAccess nereusit!");
        QMessageBox::information(this,"Actiune nereusita!","User-ul are deja acces!");
    }
    this->message=copyForNoRepeat;//pentru a nu concatena mesajele
    }

}


void PaginaSelectieFisiere::on_pushButton_5_clicked()
{
    PaginaOptiuni*newPage= new PaginaOptiuni(this->A);
    newPage->show();
    this->hide();
}


void PaginaSelectieFisiere::on_pushButton_6_clicked()  //buton delete,GiveAdmin,Branch
{
    if(this->codActiune=="5")
    {
        QString  path="C:/Users/Alex/Desktop/test/";
        if(this->combo!=nullptr)
            path+=this->combo->currentText();
        else
        if(this->comboBranch!=nullptr)
           { path=this->ui->label->text();
            path+="/";
             path.append(this->comboBranch->currentText());
        }
        else
        if(this->comboFiles!=NULL)
        {   path=this->ui->label->text();
            path+="/";
            path.append(this->comboFiles->currentText());
        }

        QByteArray text;
        this->sendMessageToServer(text,protocol.DeleteCODE+path);
        if(text=="DA")
        {   Logger::getInstance()->write("Delete reusit de " + this->A->getUsername());
            QMessageBox::information(this,"Delete reusit!","Actiunea s-a executat cu succes!");
        }
        else QMessageBox::information(this,"Eroare fatala!","Nu puteti sterge trunk!");

    }
    if(this->codActiune=="6")
    {
        QString nume=this->ui->lineEdit->text();
        QByteArray text;
        this->sendMessageToServer(text,protocol.CreateAdminCODE+nume);
        if(text=="DA")
        {   Logger::getInstance()->write("Admin "+nume+" creat cu succes!");
            QMessageBox::information(this,"OK","Admin creat cu succes!");
        }
        else QMessageBox::information(this,"Eroare","Eroare la creere admin!");

    }
    if(this->codActiune=="3")
    {
       QByteArray text;
       this->message="";
       this->message.append(protocol.BranchCODE);
       this->message.append(this->repo);
       this->message.append(" ");
       this->message.append(this->branch);
       this->message.append(" ");
       this->message.append(this->version);
       this->message.append(" ");
       this->message.append(this->ui->lineEdit->text());
       this->sendMessageToServer(text,message);
       if(text=="DA")
       {    Logger::getInstance()->write("Branch executat cu succes de "+ this->A->getUsername());
           QMessageBox::information(this,"Succes!","Branch executat cu succes!");
       }
    }
}

