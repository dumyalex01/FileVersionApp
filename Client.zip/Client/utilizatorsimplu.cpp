#include "utilizatorsimplu.h"

UtilizatorSimplu::UtilizatorSimplu(QString id, QString numeUtilizator)
{
    this->id=id.toInt();
    this->userName=numeUtilizator;
}

void UtilizatorSimplu::giveAdmin(QString numeUtilizator)
{

}
