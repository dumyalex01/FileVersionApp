#include "paginaselectietagversion.h"
#include "ui_paginaselectietagversion.h"
#include <QTcpSocket>
#include <editortext.h>
#include <QMessageBox>
PaginaSelectieTagVersion::PaginaSelectieTagVersion(QString id,IUtilizator*A,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaginaSelectieTagVersion)
{
    ui->setupUi(this);
    this->idUser=id;
    this->A=A;
    QPalette pal = this->palette();
    pal.setBrush(QPalette::Window, QBrush(QPixmap("C:/Users/Alex/Desktop/pozeProiect/fundal.jpg")));
    this->setPalette(pal);
    this->setAutoFillBackground(true);
    this->ui->lineEdit->setReadOnly(true);
    this->ui->lineEdit_3->setReadOnly(true);
    this->ui->lineEdit_5->setReadOnly(true);
}

PaginaSelectieTagVersion::~PaginaSelectieTagVersion()
{
    delete ui;
}

void PaginaSelectieTagVersion::on_pushButton_clicked()
{   if(!this->ui->lineEdit_4->text().contains(".tag"))
        QMessageBox::information(this,"Eroare","Numele nu contine extensia .tag");
    else
    {
    QString message;
    message.append("21 ");
    message.append(this->idUser);
    message.append(" ");
    message.append(this->ui->lineEdit_2->text());
    message.append(" ");
    message.append(this->ui->lineEdit_4->text());
    message.append(" ");
    message.append(this->ui->lineEdit_6->text());
    QByteArray text;
    QTcpSocket socket;
        socket.connectToHost("127.0.0.1", 1234);
        if (socket.waitForConnected()) {
            socket.write(message.toUtf8());
            socket.flush();
            if(socket.waitForReadyRead(30000))
            {
                text = socket.readAll();
            }
            socket.disconnectFromHost();
        } else {
            qDebug() << "Nu s-a putut realiza conexiunea la server!";
        }
        if(text=="NU")
            QMessageBox::information(this,"Eroare","File not found!");
        else if(text=="NO_ACCESS")
            QMessageBox::information(this,"Eroare","Nu aveti acces la acest fisier!");
        else
        {
        EditorText* edit=new EditorText(true,text,"",this->A);
        edit->show();
        }
    }
}



