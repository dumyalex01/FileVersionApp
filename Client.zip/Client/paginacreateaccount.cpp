#include "paginacreateaccount.h"
#include "ui_paginacreateaccount.h"
#include <QMessageBox>
#include "exceptieadaugareuser.h"
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QTcpSocket>
#include "exceptieparola.h"
paginaCreateAccount::paginaCreateAccount(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::paginaCreateAccount)
{
    ui->setupUi(this);
    this->setWindowTitle("App");
    QPalette pal = this->palette();
    pal.setBrush(QPalette::Window, QBrush(QPixmap("C:/Users/Alex/Desktop/primaPagina.jpg")));
    this->setMinimumSize(600,400);
    this->setMaximumSize(600,400);
    this->setPalette(pal);
    this->setAutoFillBackground(true);

}

paginaCreateAccount::~paginaCreateAccount()
{
    delete ui;
}

void paginaCreateAccount::on_pushButton_clicked()
{
    QString A=this->ui->username->text();
    QString B=this->ui->password->text();
    QString C=this->ui->confirm->text();
    QString mesaj;
    mesaj.append(protocol.AutentifCODE);
    mesaj.append(A);
    mesaj.append(" ");
    mesaj.append(B);
    try
    {
        if(B!=C)
            throw new ExceptieParola();
        else
        {
            QTcpSocket socket;
            socket.connectToHost("127.0.0.1", 1234);
                if (socket.waitForConnected()) {
            socket.write(mesaj.toUtf8());
            socket.flush();
            if(socket.waitForReadyRead(30000))
            {
                QByteArray data = socket.readAll();
                if(QString::fromUtf8(data).contains("DA"))
                {   Logger::getInstance()->write("Autentificare reusita!");
                    QMessageBox::information(this,"OK","Autentificare Reusita!");
                    this->hide();
                }
                else if(QString::fromUtf8(data)=="EXISTA")
                   { Logger::getInstance()->write("Autentificare nereusita!");
                    throw new ExceptieAdaugareUser();
                }

            }

            socket.disconnectFromHost();
        }
        else {
            qDebug() << "Nu s-a putut realiza conexiunea la server!";
       }
    }


    }
    catch (IExceptii*E)
    {
       E->throwMessage(this);
    }
}






