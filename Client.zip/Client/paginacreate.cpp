#include "paginacreate.h"
#include "ui_paginacreate.h"
#include "protocols.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QMessageBox>
PaginaCreate::PaginaCreate(IUtilizator * A,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaginaCreate)
{
    ui->setupUi(this);
    QPalette pal = this->palette();
    pal.setBrush(QPalette::Window, QBrush(QPixmap("C:/Users/Alex/Desktop/pozeProiect/fundal.jpg")));
    this->setPalette(pal);
    this->setAutoFillBackground(true);
    this->A=A;
    this->numarCurentButon=0;
    this->ui->lineEdit_2->setReadOnly(true);
}
PaginaCreate::~PaginaCreate()
{
    delete ui;

}

void PaginaCreate::on_pushButton_clicked()
{
        QByteArray text;
        Protocols prot;
        QString message=prot.CreateCODE;
        message.append(this->A->getUsername());
        message.append(" ");
        message.append(this->ui->lineEdit->text());
        qDebug()<<message;
        QTcpSocket socket;
            socket.connectToHost("127.0.0.1", 1234);
            if (socket.waitForConnected()) {
                socket.write(message.toUtf8());
                socket.flush();
                if(socket.waitForReadyRead(30000))
                {
                    text = socket.readAll();
                }
                socket.disconnectFromHost();
            } else {
                qDebug() << "Nu s-a putut realiza conexiunea la server!";
            }
            if(text=="DA")
            {
                QMessageBox::information(this,"OK!","Repository creat cu succes!");
                Logger::getInstance()->write("Repository-ul " + this->ui->lineEdit->text() +" a fost creat cu succes!");
            }
            else
            {
                QMessageBox::information(this,"Eroare!","Repository ul exista deja!");
                Logger::getInstance()->write("Repository ul exsita deja!");
            }



  }



