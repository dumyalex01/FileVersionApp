#include "exceptieuseraccess.h"

ExceptieUserAccess::ExceptieUserAccess()
{

}
