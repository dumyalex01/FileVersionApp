#ifndef EXCEPTIEADAUGAREUSER_H
#define EXCEPTIEADAUGAREUSER_H

#include "iexceptii.h"

class ExceptieAdaugareUser : public IExceptii
{
public:
    ExceptieAdaugareUser();
    void throwMessage(QWidget* parent);
};

#endif // EXCEPTIEADAUGAREUSER_H
