#ifndef PROTOCOLS_H
#define PROTOCOLS_H
#include <QString>

class Protocols
{
public:
    QString LoginCODE ="1 ";
    QString AutentifCODE ="2 ";
    QString BranchCODE="3 ";
    QString CommitCODE="4 ";
    QString DeleteCODE="5 ";
    QString CreateAdminCODE="6 ";
    QString MergeCODE="8 ";
    QString PropertiesCODE="9 ";
    QString UserDetailsCODE="10 ";
    QString ViewCODE="12 ";
    QString SendRepoCODE="13 ";
    QString SendBranchCODE="14 ";
    QString SendVersionCODE="15 ";
    QString SendCommitFileCODE="16 ";
    QString GiveAccessCODE="17 ";
    QString CreateCODE="18 ";
    QString HelpCODE="19";
    QString TagCODE="20";
    Protocols();

};

#endif // PROTOCOLS_H
