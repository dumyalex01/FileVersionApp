#include "exceptielogin.h"

ExceptieLogin::ExceptieLogin()
{

}

void ExceptieLogin::throwMessage(QWidget *parent)
{
   QMessageBox::information(parent,"Eroare","Contul sau parola nu coincid!");
}
