#include "cexceptii.h"

CExceptii::CExceptii()
{

}
