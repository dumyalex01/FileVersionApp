#include "paginaprincipala.h"
#include "ui_paginaprincipala.h"
#include "loginwindow.h"
#include "administrator.h"
#include "utilizatorsimplu.h"
#include "paginaoptiuni.h"
#include "editortext.h"
#include <QFile>
PaginaPrincipala::PaginaPrincipala(IUtilizator*A,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaginaPrincipala)
{   this->A=A;
    ui->setupUi(this);
    this->setWindowTitle("App");
    QString tipUser;
    if(dynamic_cast<Administrator*>(A)!=NULL)
        tipUser="administrator!";
    else tipUser="utilizator simplu!";
    this->ui->label->setText("Bine ai venit, "+A->getUsername()+"!\n        "+" Ai rolul de "+tipUser);
    QPalette pal = this->palette();
    pal.setBrush(QPalette::Window, QBrush(QPixmap("C:/Users/Alex/Desktop/pozeProiect/fundal.jpg")));
    this->setPalette(pal);
    this->setAutoFillBackground(true);
    this->setMaximumSize(800,500);
    this->setMinimumSize(800,500);
}

PaginaPrincipala::~PaginaPrincipala()
{
    delete ui;
}

void PaginaPrincipala::on_pushButton_3_clicked()
{
    this->hide();
    LoginWindow* A=new LoginWindow();
    A->show();
}


void PaginaPrincipala::on_pushButton_clicked()
{
    PaginaOptiuni*A=new PaginaOptiuni(this->A);
    A->show();
    this->hide();
}


void PaginaPrincipala::on_pushButton_2_clicked()
{

    QString path;
    QByteArray text;
    QString aux;
    if(dynamic_cast<Administrator*>(A)!=NULL)
        path="C:/Users/Alex/Desktop/test/detailsAdmin.txt";
    else path="C:/Users/Alex/Desktop/test/details.txt";
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
       qDebug()<<"eroare";
    }
    else{
        while(!f.atEnd())
        {
           text=f.readLine();
           aux+=QString::fromUtf8(text);
        }
    }
    EditorText*B=new EditorText(true,aux.toUtf8(),"",this->A);
    B->show();
}

