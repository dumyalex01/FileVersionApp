#include "editortext.h"
#include "ui_editortext.h"
#include <QTcpSocket>
#include <QMessageBox>
#include "logger.h"
EditorText::EditorText(bool readOnly,QByteArray a,QString path,IUtilizator*A,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EditorText)
{   this->pathForCommit=path;
    this->A=A;
    ui->setupUi(this);
    if(readOnly)
    {
        this->ui->plainTextEdit->setReadOnly(true);
        this->ui->plainTextEdit->setPlainText(a);
        this->ui->pushButton->hide();

    }
    else
    {
        this->ui->plainTextEdit->setPlainText(a);
    }

}

EditorText::~EditorText()
{
    delete ui;
}

void EditorText::on_pushButton_clicked()
{
    QByteArray text;
    QString message="4~"; //commit
    pathForCommit.append("/");
    pathForCommit.append(A->getUsername());
    message.append(pathForCommit);
    message.append("~");
    message.append(this->ui->plainTextEdit->toPlainText());
    QTcpSocket socket;
        socket.connectToHost("127.0.0.1", 1234);
        if (socket.waitForConnected()) {
            socket.write(message.toUtf8());
            socket.flush();
            if(socket.waitForReadyRead(30000))
            {
                text = socket.readAll();
            }
            socket.disconnectFromHost();
        } else {
            qDebug() << "Nu s-a putut realiza conexiunea la server!";
        }
        if(text=="7")
        { Logger::getInstance()->write("Commit executat cu succes!");
           QMessageBox::information(this,"OK!","S-a creat o versiune noua!");
        }
        else
        {
            Logger::getInstance()->write("Commit neexecutat!");
            QMessageBox::information(this,"Eroare","Nu s-a creat o versiune noua!");
        }
}

