#ifndef PAGINASELECTIETAGVERSION_H
#define PAGINASELECTIETAGVERSION_H
#include "iutilizator.h"
#include <QWidget>
#include "logger.h"
namespace Ui {
class PaginaSelectieTagVersion;
}

class PaginaSelectieTagVersion : public QWidget
{
    Q_OBJECT

public:
    explicit PaginaSelectieTagVersion(QString id,IUtilizator*A,QWidget *parent = nullptr);
    ~PaginaSelectieTagVersion();

private slots:
    void on_pushButton_clicked();

private:
    QString idUser;
    IUtilizator*A;
    Ui::PaginaSelectieTagVersion *ui;
};

#endif // PAGINASELECTIETAGVERSION_H
