
#ifndef LOGGER_H
#define LOGGER_H

#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
using namespace std;

class Logger
{
private:
private:
    Logger();
   static QString path;
    ~Logger() = default;
   static Logger* Instance;
   static QString m_fileName;
   QString setMessage(QString message);
public:
    static Logger* getInstance();
    void write(const QString& message);
};

#endif // LOGGER_H
