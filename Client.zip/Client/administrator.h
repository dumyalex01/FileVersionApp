#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
#include "cutilizator.h"

class Administrator: public CUtilizator
{
public:
    void giveAdmin(QString numeUtilizator);
    bool setAcces();
    Administrator(QString id,QString userName);
};

#endif // ADMINISTRATOR_H
