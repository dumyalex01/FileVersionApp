#include "paginaoptiuni.h"
#include "ui_paginaoptiuni.h"
#include "paginaselectiefisiere.h"
#include "editortext.h"
#include "loginwindow.h"
#include "administrator.h"
#include "utilizatorsimplu.h"
#include <QTcpSocket>
#include <QMessageBox>
#include "paginacreate.h"
#include <QPropertyAnimation>
#include "paginaselectietagversion.h"
PaginaOptiuni::PaginaOptiuni(IUtilizator* A,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaginaOptiuni)
{   this->A=A;
    ui->setupUi(this);
    QPalette pal = this->palette();
    pal.setBrush(QPalette::Window, QBrush(QPixmap("C:/Users/Alex/Desktop/pozeProiect/fundal.jpg")));
    this->setPalette(pal);
    this->setAutoFillBackground(true);
    this->ui->pushButton->hide(); //il ascund pentru ca ii dau un design in ui, dar la rulare nu apare cum trebuie
    if(dynamic_cast<Administrator*>(A)==NULL)
      { this->ui->pushButton_11->hide();
        this->ui->pushButton_12->hide();
    }
    this->ui->lineEdit->setReadOnly(true);
    this->ui->lineEdit->hide();
    this->ui->lineEdit_2->hide();
    this->ui->pushButton_13->hide();
   this->ui->pushButton->setStyleSheet("background-color: #1abc9c;");
   this->ui->pushButton->setStyleSheet("color: white;");
   this->ui->pushButton->setStyleSheet("box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.2);");

}

PaginaOptiuni::~PaginaOptiuni()
{
    delete ui;
}

void PaginaOptiuni::on_pushButton_7_clicked()
{
    PaginaSelectieFisiere* B=new PaginaSelectieFisiere(this->A,"12"); //view
    B->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_10_clicked()  //Properties
{   QString message;
    QByteArray text;
    QByteArray toReceive;
    text.append("Listele de acces ale utilizatorilor la fisierele la care aveti si dvs. acces sunt : \n");
    QString id=QString::number(this->A->getID());
    message.append(protocol.PropertiesCODE);
    message.append(id);
    this->sendMessageToServer(toReceive,message);
    text.append(toReceive);
    EditorText* edit=new EditorText(true,text,"",this->A);
    edit->show();

}

void PaginaOptiuni::sendMessageToServer(QByteArray &text, QString message)
{
    QTcpSocket socket;
        socket.connectToHost("127.0.0.1", 1234);
        if (socket.waitForConnected()) {
            socket.write(message.toUtf8());
            socket.flush();
            if(socket.waitForReadyRead(30000))
            {
                text = socket.readAll();
            }
            socket.disconnectFromHost();
        } else {
            qDebug() << "Nu s-a putut realiza conexiunea la server!";
        }
}


void PaginaOptiuni::on_pushButton_6_clicked()  //GiveAccess
{
    PaginaSelectieFisiere* B = new PaginaSelectieFisiere(this->A,"17");//17 reprezinta id ul actiunii GiveAccess
    B->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_5_clicked()
{   QByteArray text;
    this->sendMessageToServer(text,protocol.HelpCODE);
    EditorText* A=new EditorText(true,text,"",this->A);
    A->show();
}


void PaginaOptiuni::on_pushButton_9_clicked()
{
    LoginWindow* win=new LoginWindow();
    this->hide();
    win->show();
}


void PaginaOptiuni::on_pushButton_12_clicked()
{
    this->ui->lineEdit->show();
    this->ui->lineEdit_2->show();
    this->ui->pushButton_13->show();


}


void PaginaOptiuni::on_pushButton_13_clicked()  //Properties
{   QByteArray text;
    QString textFinal="Repository-urile la care are acces utilizatorul " + this->ui->lineEdit_2->text()+" sunt:\n";
    QByteArray TextFinal=textFinal.toUtf8();
    QString userInserted=this->ui->lineEdit_2->text();
    QString messageForServer=protocol.UserDetailsCODE;
    messageForServer.append(userInserted);
    this->sendMessageToServer(text,messageForServer);
    TextFinal.append(text);
    if(text=="EROARE")
        QMessageBox::information(this,"User invalid","User-ul nu a fost gasit!");
    else
    {   Logger::getInstance()->write("S-a apelat Properties de catre " + this->A->getUsername());
        this->ui->lineEdit->hide();
        this->ui->lineEdit_2->hide();
        this->ui->pushButton_13->hide();
    EditorText* E=new EditorText(true,TextFinal,"",this->A);
    E->setMinimumWidth(500);
    E->setMaximumWidth(500);
    E->setMaximumHeight(300);
    E->setMinimumHeight(300);
    E->show();
    }
}


void PaginaOptiuni::on_pushButton_8_clicked() //delete
{
    PaginaSelectieFisiere* newPage=new PaginaSelectieFisiere(this->A,"5");
    newPage->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_11_clicked() //admin
{
    PaginaSelectieFisiere* newPage= new PaginaSelectieFisiere(this->A,"6");
    newPage->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_3_clicked()
{
    PaginaSelectieFisiere* newPage=new PaginaSelectieFisiere(this->A,"3"); //branch
    newPage->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_15_clicked()
{
    PaginaCreate*newPage=new PaginaCreate(this->A);
    newPage->show();

}


void PaginaOptiuni::on_pushButton_2_clicked()
{
    PaginaSelectieFisiere* newPage=new PaginaSelectieFisiere(this->A,"16");
    newPage->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_4_clicked()
{
    PaginaSelectieFisiere* newPage= new PaginaSelectieFisiere(this->A,"8");
    newPage->show();
    this->hide();
}


void PaginaOptiuni::on_pushButton_14_clicked()
{
    QByteArray text;
    PaginaSelectieFisiere* newPage= new PaginaSelectieFisiere(this->A,"20");
    newPage->show();
}


void PaginaOptiuni::on_pushButton_16_clicked()
{
    PaginaSelectieTagVersion* pag=new PaginaSelectieTagVersion(QString::number(this->A->getID()),this->A);
    pag->show();
}

