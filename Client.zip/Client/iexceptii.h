#ifndef IEXCEPTII_H
#define IEXCEPTII_H
#include <QMessageBox>
#include <QObject>

class IExceptii
{
public:
    virtual void throwMessage(QWidget* parent)=0;
};

#endif // IEXCEPTII_H
