#include "exceptieadministrator.h"

ExceptieAdministrator::ExceptieAdministrator()
{

}

void ExceptieAdministrator::throwMessage(QWidget* parent)
{
    QMessageBox::information(parent,"Eroare","User-ul nu are acces la a da administrator!");
}
