#ifndef CUTILIZATOR_H
#define CUTILIZATOR_H
#include "iutilizator.h"
#include <iostream>
#include <vector>
using namespace std;


class CUtilizator : public IUtilizator
{
protected:
    QString userName;
    int id;

public:
    CUtilizator();
    virtual ~CUtilizator();
    virtual void giveAdmin(QString numeUtilizator)=0;
    QString getUsername() override;
    virtual int getID() override;
};

#endif // CUTILIZATOR_H
