#include "loginwindow.h"
#include "ui_loginwindow.h"
#include <QLabel>
#include <paginaprincipala.h>
#include <QMessageBox>
#include <paginacreateaccount.h>
#include <QTcpSocket>
#include "utilizatorsimplu.h"
#include "administrator.h"
QString tipUtilizator;
LoginWindow::LoginWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LoginWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("App");
    QPalette pal = this->palette();
    pal.setBrush(QPalette::Window, QBrush(QPixmap("C:/Users/Alex/Desktop/pozeProiect/fundal.jpg")));
    this->setPalette(pal);
    this->setAutoFillBackground(true);
    this->setMinimumSize(800,500);
    this->setMaximumSize(800,500);

}

LoginWindow::~LoginWindow()
{
    delete ui;
}


void LoginWindow::on_loginButton_clicked()
{         QTcpSocket socket;
          QString user;
          QString parola;
          user=this->ui->Username->text();
          parola=this->ui->Password->text();
          QString mesaj;
          mesaj.append(protocol.LoginCODE);
          mesaj.append(user);
          mesaj.append(" ");
          mesaj.append(parola);

          socket.connectToHost("127.0.0.1", 1234);
          if (socket.waitForConnected()) {
              socket.write(mesaj.toUtf8());
              socket.flush();
              if(socket.waitForReadyRead(30000))
              {
                  QByteArray data = socket.readAll();
                  QString mesaj=QString::fromUtf8(data);
                  QStringList lista=mesaj.split(" ");
                  if(lista.at(0)=="DA")
                  {
                      if(lista.at(2)=="admin")
                        this->A=new Administrator(lista.at(1),user);
                      else this->A=new UtilizatorSimplu(lista.at(1),user);
                      PaginaPrincipala* prin=new PaginaPrincipala(A);
                      prin->show();
                      this->hide();
                      Logger::getInstance()->write("Utilizatorul " + this->A->getUsername()+" s-a logat cu succes!");
                  }

                  else {QMessageBox::information(this,"Eroare conexiune","Contul sau parola sunt incorecte!");
                      Logger::getInstance()->write("Login FAILED!");
                  }
              }

              socket.disconnectFromHost();
          } else {
              qDebug() << "Nu s-a putut realiza conexiunea la server!";
         }
}

void LoginWindow::on_registerButton_clicked()
{
    this->hide();
    paginaCreateAccount* pag = new paginaCreateAccount();
    pag->show();

}

