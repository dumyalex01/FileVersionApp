#ifndef PAGINAPRINCIPALA_H
#define PAGINAPRINCIPALA_H
#include "iutilizator.h"
#include "utilizatorsimplu.h"
#include <QWidget>
#include "logger.h"
namespace Ui {
class PaginaPrincipala;
}

class PaginaPrincipala : public QWidget
{
    Q_OBJECT

public:
    explicit PaginaPrincipala(IUtilizator*A,QWidget *parent = nullptr);
    ~PaginaPrincipala();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    IUtilizator*A;
    Ui::PaginaPrincipala *ui;
};

#endif // PAGINAPRINCIPALA_H
