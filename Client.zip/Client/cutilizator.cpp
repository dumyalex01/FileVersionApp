#include "cutilizator.h"

CUtilizator::CUtilizator()
{


}

CUtilizator::~CUtilizator()
{

}

QString CUtilizator::getUsername()
{
    return this->userName;
}

int CUtilizator::getID()
{return this->id;

}

