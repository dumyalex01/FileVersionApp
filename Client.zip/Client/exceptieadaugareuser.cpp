#include "exceptieadaugareuser.h"
#include <QMessageBox>
ExceptieAdaugareUser::ExceptieAdaugareUser()
{

}

void ExceptieAdaugareUser::throwMessage(QWidget *parent)
{
    QMessageBox::information(parent,"Eroare","Username-ul exista deja in baza de date!");
}
