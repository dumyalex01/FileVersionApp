#include "exceptieparola.h"

ExceptieParola::ExceptieParola()
{

}

void ExceptieParola::throwMessage(QWidget *parent)
{
    QMessageBox::information(parent,"Eroare","Parolele introduse nu coincid!");
}
