#ifndef EXCEPTIELOGIN_H
#define EXCEPTIELOGIN_H

#include "iexceptii.h"

class ExceptieLogin : public IExceptii
{
public:
    ExceptieLogin();
    void throwMessage(QWidget* parent);
};

#endif // EXCEPTIELOGIN_H
