#ifndef PAGINACREATE_H
#define PAGINACREATE_H

#include <QWidget>
#include "utilizatorsimplu.h"
#include "administrator.h"
#include "iutilizator.h"
#include "logger.h"

namespace Ui {
class PaginaCreate;
}

class PaginaCreate : public QWidget
{
    Q_OBJECT

public:
    explicit PaginaCreate(IUtilizator*A,QWidget *parent = nullptr);
    ~PaginaCreate();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    int numarCurentButon;
    IUtilizator*A;
    Ui::PaginaCreate *ui;
};

#endif // PAGINACREATE_H
