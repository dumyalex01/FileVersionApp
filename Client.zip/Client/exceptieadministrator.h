#ifndef EXCEPTIEADMINISTRATOR_H
#define EXCEPTIEADMINISTRATOR_H
#include "iexceptii.h"
#include <QObject>

class ExceptieAdministrator: public IExceptii
{
public:
    ExceptieAdministrator();
    void throwMessage(QWidget* parent);
};

#endif // EXCEPTIEADMINISTRATOR_H
