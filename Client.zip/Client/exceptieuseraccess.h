#ifndef EXCEPTIEUSERACCESS_H
#define EXCEPTIEUSERACCESS_H

#include "iexceptii.h"

class ExceptieUserAccess : public IExceptii
{
public:
    ExceptieUserAccess();
};

#endif // EXCEPTIEUSERACCESS_H
