#include "paginaoptiuniadmin.h"
#include "ui_paginaoptiuniadmin.h"

PaginaOptiuniAdmin::PaginaOptiuniAdmin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaginaOptiuniAdmin)
{
    ui->setupUi(this);
}

PaginaOptiuniAdmin::~PaginaOptiuniAdmin()
{
    delete ui;
}
